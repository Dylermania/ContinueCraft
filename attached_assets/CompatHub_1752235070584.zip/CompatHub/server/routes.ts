import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { insertDeviceSchema, insertCompatibilityCheckSchema } from "@shared/schema";
import mobileApiRouter from "./mobile-api";
import { EmulationService } from "./emulation-service";
import path from "path";
import fs from "fs";
import { AppStoreSync } from "./app-store-sync";

export async function registerRoutes(app: Express): Promise<Server> {

  // Mount mobile API routes
  app.use("/api", mobileApiRouter);

  // Get user device
  app.get("/api/device/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const device = await storage.getDeviceByUserId(userId);
      res.json(device);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch device" });
    }
  });

  // Save device specs
  app.post("/api/device", async (req, res) => {
    try {
      const deviceData = insertDeviceSchema.parse(req.body);

      // Check if device exists for user, update or create
      const existingDevice = await storage.getDeviceByUserId(deviceData.userId!);
      if (existingDevice) {
        const updatedDevice = await storage.updateDevice(existingDevice.id, deviceData);
        res.json(updatedDevice);
      } else {
        const device = await storage.createDevice(deviceData);
        res.json(device);
      }
    } catch (error) {
      res.status(400).json({ message: "Invalid device data" });
    }
  });

  // Get popular apps
  app.get("/api/apps/popular", async (req, res) => {
    try {
      const apps = await storage.getPopularApps();
      res.json(apps);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch popular apps" });
    }
  });

  // Get app by ID
  app.get("/api/apps/:id", async (req, res) => {
    try {
      const appId = parseInt(req.params.id);
      const app = await storage.getApp(appId);
      if (!app) {
        return res.status(404).json({ message: "App not found" });
      }
      res.json(app);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch app" });
    }
  });

  // Check app compatibility
  app.post("/api/compatibility/check", async (req, res) => {
    try {
      const { userId, deviceId, appId } = req.body;

      const device = await storage.getDevice(deviceId);
      const app = await storage.getApp(appId);

      if (!device || !app) {
        return res.status(404).json({ message: "Device or app not found" });
      }

      // Compatibility algorithm
      const issues: string[] = [];
      let compatibilityScore = 100;

      // Check RAM
      if (device.ram < app.requiredRam) {
        issues.push("RAM");
        compatibilityScore -= 30;
      }

      // Check Android version (API level)
      const deviceApiLevel = getApiLevelFromVersion(device.osVersion);
      if (deviceApiLevel < app.minSdkVersion) {
        issues.push("Android Version");
        compatibilityScore -= 25;
      }

      // Check storage
      const requiredStorageMB = app.requiredStorage;
      const availableStorageGB = device.freeStorage;
      const availableStorageMB = availableStorageGB * 1024;

      if (availableStorageMB < requiredStorageMB) {
        issues.push("Storage");
        compatibilityScore -= 20;
      }

      // Check GPU requirements (simplified)
      if (app.requiredFeatures && app.requiredFeatures.includes("vulkan") && !device.gpu.includes("Adreno 6")) {
        issues.push("GPU");
        compatibilityScore -= 25;
      }

      const isCompatible = issues.length === 0;
      compatibilityScore = Math.max(0, compatibilityScore);

      // Generate suggestions
      const suggestions: string[] = [];
      if (!isCompatible) {
        if (issues.includes("RAM")) {
          suggestions.push("lite_version", "emulation");
        }
        if (issues.includes("Android Version")) {
          suggestions.push("patch_apk");
        }
        if (issues.includes("Storage")) {
          suggestions.push("clear_cache", "lite_version");
        }
        if (issues.includes("GPU")) {
          suggestions.push("emulation", "reduce_graphics");
        }
      }

      const checkData = {
        userId,
        deviceId,
        appId,
        isCompatible,
        compatibilityScore,
        issues,
        suggestions
      };

      const check = await storage.createCompatibilityCheck(checkData);
      res.json(check);
    } catch (error) {
      res.status(500).json({ message: "Failed to check compatibility" });
    }
  });

  // Get compatibility history for user
  app.get("/api/compatibility/history/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const checks = await storage.getCompatibilityChecksByUserId(userId);

      // Include app details
      const checksWithApps = await Promise.all(
        checks.map(async (check) => {
          const app = check.appId ? await storage.getApp(check.appId) : null;
          return { ...check, app };
        })
      );

      res.json(checksWithApps);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch compatibility history" });
    }
  });

  // Parse APK file (mock implementation)
  app.post("/api/apk/parse", async (req, res) => {
    try {
      // In a real implementation, this would parse the actual APK file
      // For now, return mock data based on file name or simulate parsing
      const mockApkData = {
        name: "Custom App",
        packageName: "com.custom.app",
        version: "1.0.0",
        minSdkVersion: 21,
        targetSdkVersion: 30,
        requiredRam: 2048,
        requiredStorage: 500,
        requiredFeatures: ["camera"],
        permissions: ["INTERNET", "CAMERA"]
      };

      res.json(mockApkData);
    } catch (error) {
      res.status(500).json({ message: "Failed to parse APK" });
    }
  });

  // Get saved fixes for user
  app.get("/api/fixes/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const fixes = await storage.getSavedFixesByUserId(userId);
      res.json(fixes);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch saved fixes" });
    }
  });

  // Emulation endpoints
  const emulationService = EmulationService.getInstance();

  // Start emulation session
  app.post("/api/emulation/start", async (req, res) => {
    try {
      const { userId, appId, deviceId } = req.body;
      const session = await emulationService.createEmulationSession(userId, appId, deviceId);
      res.json(session);
    } catch (error) {
      res.status(500).json({ message: "Failed to start emulation session" });
    }
  });

  // Get emulation session
  app.get("/api/emulation/session/:sessionId", async (req, res) => {
    try {
      const session = await emulationService.getSession(req.params.sessionId);
      if (!session) {
        return res.status(404).json({ message: "Session not found" });
      }
      res.json(session);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch session" });
    }
  });

  // Control emulation session
  app.post("/api/emulation/session/:sessionId/:action", async (req, res) => {
    try {
      const { sessionId, action } = req.params;

      switch (action) {
        case 'pause':
          await emulationService.pauseSession(sessionId);
          break;
        case 'resume':
          await emulationService.resumeSession(sessionId);
          break;
        case 'stop':
          await emulationService.stopSession(sessionId);
          break;
        default:
          return res.status(400).json({ message: "Invalid action" });
      }

      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "Failed to control session" });
    }
  });

  // Get user's active sessions
  app.get("/api/emulation/sessions/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const sessions = await emulationService.getUserSessions(userId);
      res.json(sessions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch user sessions" });
    }
  });

  // App store sync endpoints
  const appStoreSync = AppStoreSync.getInstance();

  // Manually trigger app store sync
  app.post("/api/sync/app-stores", async (req, res) => {
    try {
      await appStoreSync.syncAppStores();
      res.json({ message: "App store sync completed" });
    } catch (error) {
      res.status(500).json({ message: "Failed to sync app stores" });
    }
  });

  // Start periodic sync
  appStoreSync.startPeriodicSync();

  // Download page
  app.get("/download", (req, res) => {
    const downloadPagePath = path.join(process.cwd(), "download.html");
    res.sendFile(downloadPagePath);
  });

  // APK Download endpoint
  app.get("/download/apk", (req, res) => {
    const apkPath = path.join(process.cwd(), "CompatHub-debug.apk");

    if (fs.existsSync(apkPath)) {
      res.download(apkPath, "CompatHub.apk", (err) => {
        if (err) {
          console.error("Error downloading APK:", err);
          res.status(500).json({ error: "Failed to download APK" });
        }
      });
    } else {
      res.status(404).json({ error: "APK file not found. Please build the APK first." });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

function getApiLevelFromVersion(osVersion: string): number {
  // Extract API level from Android version string
  const match = osVersion.match(/API (\d+)/);
  if (match) {
    return parseInt(match[1]);
  }

  // Fallback mapping for common versions
  const versionMap: { [key: string]: number } = {
    "10": 29,
    "11": 30,
    "12": 31,
    "13": 33,
    "14": 34
  };

  const version = osVersion.split(" ")[1];
  return versionMap[version] || 21;
}
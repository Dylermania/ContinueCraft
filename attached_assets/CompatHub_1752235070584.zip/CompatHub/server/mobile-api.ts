import { Router } from "express";
import { storage } from "./storage";
import { insertDeviceSchema, insertAppSchema, insertCompatibilityCheckSchema } from "@shared/schema";

const router = Router();

// Mobile-specific API endpoints for offline functionality
router.get("/mobile/popular-apps", async (req, res) => {
  try {
    const apps = await storage.getPopularApps();
    res.json({
      apps,
      lastUpdated: new Date().toISOString(),
      version: "1.0.0"
    });
  } catch (error) {
    console.error("Error fetching popular apps:", error);
    res.status(500).json({ message: "Failed to fetch popular apps" });
  }
});

// Sync device specs for mobile app
router.post("/mobile/sync-device", async (req, res) => {
  try {
    const deviceData = insertDeviceSchema.parse(req.body);
    
    // Check if device already exists for this user
    let device = await storage.getDeviceByUserId(deviceData.userId || 1);
    
    if (device) {
      // Update existing device
      device = await storage.updateDevice(device.id, deviceData);
    } else {
      // Create new device
      device = await storage.createDevice(deviceData);
    }
    
    res.json({
      device,
      syncedAt: new Date().toISOString()
    });
  } catch (error) {
    console.error("Error syncing device:", error);
    res.status(500).json({ message: "Failed to sync device data" });
  }
});

// Batch compatibility check for mobile
router.post("/mobile/batch-compatibility", async (req, res) => {
  try {
    const { appIds, deviceId } = req.body;
    
    if (!Array.isArray(appIds) || !deviceId) {
      return res.status(400).json({ message: "Invalid request format" });
    }
    
    const device = await storage.getDevice(deviceId);
    if (!device) {
      return res.status(404).json({ message: "Device not found" });
    }
    
    const results = [];
    
    for (const appId of appIds) {
      const app = await storage.getApp(appId);
      if (!app) continue;
      
      // Perform compatibility check
      let compatibilityScore = 100;
      const issues = [];
      
      // Check RAM requirements
      if (app.requiredRam > device.ram) {
        issues.push("RAM");
        compatibilityScore -= 30;
      }
      
      // Check storage requirements
      if (app.requiredStorage > device.freeStorage * 1024) {
        issues.push("Storage");
        compatibilityScore -= 20;
      }
      
      // Check Android version (simplified)
      const deviceApiLevel = getAPILevel(device.osVersion);
      if (app.minSdkVersion > deviceApiLevel) {
        issues.push("Android Version");
        compatibilityScore -= 40;
      }
      
      const isCompatible = compatibilityScore >= 70;
      
      const compatibilityCheck = await storage.createCompatibilityCheck({
        userId: device.userId,
        deviceId: device.id,
        appId: app.id,
        isCompatible,
        compatibilityScore: Math.max(0, compatibilityScore),
        issues,
        suggestions: isCompatible ? [] : [
          "Consider using a lite version",
          "Try emulation mode",
          "Free up storage space"
        ]
      });
      
      results.push({
        app,
        compatibility: compatibilityCheck
      });
    }
    
    res.json({
      results,
      checkedAt: new Date().toISOString(),
      deviceSpecs: device
    });
  } catch (error) {
    console.error("Error in batch compatibility check:", error);
    res.status(500).json({ message: "Failed to perform compatibility checks" });
  }
});

// Mobile app configuration endpoint
router.get("/mobile/config", async (req, res) => {
  res.json({
    version: "1.0.0",
    features: {
      deviceScanning: true,
      apkUpload: true,
      emulation: true,
      cloudRun: false,
      offline: true
    },
    limits: {
      maxApkSize: 100 * 1024 * 1024, // 100MB
      maxAppsPerBatch: 50,
      cacheRetention: 7 * 24 * 60 * 60 * 1000 // 7 days
    },
    endpoints: {
      sync: "/api/mobile/sync-device",
      popularApps: "/api/mobile/popular-apps",
      batchCheck: "/api/mobile/batch-compatibility"
    }
  });
});

function getAPILevel(androidVersion: string): number {
  const versionMap: { [key: string]: number } = {
    "14": 34, "13": 33, "12": 31, "11": 30, "10": 29,
    "9": 28, "8.1": 27, "8.0": 26, "7.1": 25, "7.0": 24
  };
  
  return versionMap[androidVersion] || 29;
}

export default router;
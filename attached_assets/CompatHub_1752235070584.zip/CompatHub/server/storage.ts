import { 
  users, devices, apps, compatibilityChecks, savedFixes,
  type User, type InsertUser,
  type Device, type InsertDevice,
  type App, type InsertApp,
  type CompatibilityCheck, type InsertCompatibilityCheck,
  type SavedFix, type InsertSavedFix
} from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Devices
  getDevice(id: number): Promise<Device | undefined>;
  getDeviceByUserId(userId: number): Promise<Device | undefined>;
  createDevice(device: InsertDevice): Promise<Device>;
  updateDevice(id: number, device: Partial<Device>): Promise<Device | undefined>;

  // Apps
  getApp(id: number): Promise<App | undefined>;
  getAppByPackageName(packageName: string): Promise<App | undefined>;
  getAllApps(): Promise<App[]>;
  getPopularApps(): Promise<App[]>;
  createApp(app: InsertApp): Promise<App>;

  // Compatibility Checks
  getCompatibilityCheck(id: number): Promise<CompatibilityCheck | undefined>;
  getCompatibilityChecksByUserId(userId: number): Promise<CompatibilityCheck[]>;
  createCompatibilityCheck(check: InsertCompatibilityCheck): Promise<CompatibilityCheck>;

  // Saved Fixes
  getSavedFixesByUserId(userId: number): Promise<SavedFix[]>;
  createSavedFix(fix: InsertSavedFix): Promise<SavedFix>;
  deleteSavedFix(id: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private devices: Map<number, Device>;
  private apps: Map<number, App>;
  private compatibilityChecks: Map<number, CompatibilityCheck>;
  private savedFixes: Map<number, SavedFix>;
  private currentUserId: number;
  private currentDeviceId: number;
  private currentAppId: number;
  private currentCheckId: number;
  private currentFixId: number;

  constructor() {
    this.users = new Map();
    this.devices = new Map();
    this.apps = new Map();
    this.compatibilityChecks = new Map();
    this.savedFixes = new Map();
    this.currentUserId = 1;
    this.currentDeviceId = 1;
    this.currentAppId = 1;
    this.currentCheckId = 1;
    this.currentFixId = 1;

    // Initialize with some popular apps
    this.initializePopularApps();
  }

  private initializePopularApps() {
    const popularApps: InsertApp[] = [
      {
        name: "Genshin Impact",
        packageName: "com.mihoyo.genshin",
        version: "4.2.0",
        category: "Action RPG",
        minSdkVersion: 26,
        targetSdkVersion: 33,
        requiredRam: 4096,
        requiredStorage: 8000,
        requiredFeatures: ["vulkan", "opengl_es_3"],
        permissions: ["INTERNET", "WRITE_EXTERNAL_STORAGE", "CAMERA"],
        iconUrl: "https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?w=80&h=80&fit=crop"
      },
      {
        name: "Call of Duty Mobile",
        packageName: "com.activision.callofduty.shooter",
        version: "1.0.34",
        category: "Battle Royale",
        minSdkVersion: 21,
        targetSdkVersion: 30,
        requiredRam: 3072,
        requiredStorage: 4000,
        requiredFeatures: ["accelerometer", "gyroscope"],
        permissions: ["INTERNET", "ACCESS_NETWORK_STATE", "RECORD_AUDIO"],
        iconUrl: "https://images.unsplash.com/photo-1542751371-adc38448a05e?w=80&h=80&fit=crop"
      },
      {
        name: "Adobe Photoshop",
        packageName: "com.adobe.photoshop",
        version: "23.0.0",
        category: "Photo Editor",
        minSdkVersion: 24,
        targetSdkVersion: 31,
        requiredRam: 2048,
        requiredStorage: 1500,
        requiredFeatures: ["camera", "touchscreen"],
        permissions: ["CAMERA", "READ_EXTERNAL_STORAGE", "WRITE_EXTERNAL_STORAGE"],
        iconUrl: "https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=80&h=80&fit=crop"
      }
    ];

    popularApps.forEach(app => {
      this.createApp(app);
    });
  }

  // Users
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const user: User = { ...insertUser, id: this.currentUserId++ };
    this.users.set(user.id, user);
    return user;
  }

  // Devices
  async getDevice(id: number): Promise<Device | undefined> {
    return this.devices.get(id);
  }

  async getDeviceByUserId(userId: number): Promise<Device | undefined> {
    return Array.from(this.devices.values()).find(device => device.userId === userId);
  }

  async createDevice(insertDevice: InsertDevice): Promise<Device> {
    const device: Device = { 
      ...insertDevice,
      userId: insertDevice.userId || null,
      isRooted: insertDevice.isRooted || false,
      id: this.currentDeviceId++,
      lastScanned: new Date()
    };
    this.devices.set(device.id, device);
    return device;
  }

  async updateDevice(id: number, updateData: Partial<Device>): Promise<Device | undefined> {
    const device = this.devices.get(id);
    if (!device) return undefined;

    const updatedDevice = { ...device, ...updateData, lastScanned: new Date() };
    this.devices.set(id, updatedDevice);
    return updatedDevice;
  }

  // Apps
  async getApp(id: number): Promise<App | undefined> {
    return this.apps.get(id);
  }

  async getAppByPackageName(packageName: string): Promise<App | undefined> {
    return Array.from(this.apps.values()).find(app => app.packageName === packageName);
  }

  async getAllApps(): Promise<App[]> {
    return Array.from(this.apps.values());
  }

  async getPopularApps(): Promise<App[]> {
    return Array.from(this.apps.values()).slice(0, 10);
  }

  async createApp(insertApp: InsertApp): Promise<App> {
    const app: App = { 
      ...insertApp, 
      id: this.currentAppId++,
      requiredFeatures: Array.isArray(insertApp.requiredFeatures) ? insertApp.requiredFeatures as string[] : [],
      permissions: Array.isArray(insertApp.permissions) ? insertApp.permissions as string[] : [],
      iconUrl: insertApp.iconUrl || null
    };
    this.apps.set(app.id, app);
    return app;
  }

  // Compatibility Checks
  async getCompatibilityCheck(id: number): Promise<CompatibilityCheck | undefined> {
    return this.compatibilityChecks.get(id);
  }

  async getCompatibilityChecksByUserId(userId: number): Promise<CompatibilityCheck[]> {
    return Array.from(this.compatibilityChecks.values())
      .filter(check => check.userId === userId)
      .sort((a, b) => new Date(b.checkedAt || 0).getTime() - new Date(a.checkedAt || 0).getTime());
  }

  async createCompatibilityCheck(insertCheck: InsertCompatibilityCheck): Promise<CompatibilityCheck> {
    const check: CompatibilityCheck = { 
      ...insertCheck,
      userId: insertCheck.userId || null,
      deviceId: insertCheck.deviceId || null,
      appId: insertCheck.appId || null,
      issues: Array.isArray(insertCheck.issues) ? insertCheck.issues as string[] : [],
      suggestions: Array.isArray(insertCheck.suggestions) ? insertCheck.suggestions as string[] : [],
      id: this.currentCheckId++,
      checkedAt: new Date()
    };
    this.compatibilityChecks.set(check.id, check);
    return check;
  }

  // Saved Fixes
  async getSavedFixesByUserId(userId: number): Promise<SavedFix[]> {
    return Array.from(this.savedFixes.values()).filter(fix => fix.userId === userId);
  }

  async createSavedFix(insertFix: InsertSavedFix): Promise<SavedFix> {
    const fix: SavedFix = { 
      ...insertFix, 
      userId: insertFix.userId || null,
      appId: insertFix.appId || null,
      downloadUrl: insertFix.downloadUrl || null,
      isBookmarked: insertFix.isBookmarked || true,
      id: this.currentFixId++ 
    };
    this.savedFixes.set(fix.id, fix);
    return fix;
  }

  async deleteSavedFix(id: number): Promise<boolean> {
    return this.savedFixes.delete(id);
  }

  async updateApp(id: number, appData: Partial<InsertApp>): Promise<App | undefined> {
    const app = this.apps.get(id);
    if (!app) return undefined;

    const updatedApp = { ...app, ...appData };
    this.apps.set(id, updatedApp);
    return updatedApp;
  }
}

// rewrite MemStorage to DatabaseStorage
export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values([insertUser])
      .returning();
    return user;
  }

  async getDevice(id: number): Promise<Device | undefined> {
    const [device] = await db.select().from(devices).where(eq(devices.id, id));
    return device || undefined;
  }

  async getDeviceByUserId(userId: number): Promise<Device | undefined> {
    const [device] = await db.select().from(devices).where(eq(devices.userId, userId));
    return device || undefined;
  }

  async createDevice(insertDevice: InsertDevice): Promise<Device> {
    const [device] = await db
      .insert(devices)
      .values([insertDevice])
      .returning();
    return device;
  }

  async updateDevice(id: number, updateData: Partial<Device>): Promise<Device | undefined> {
    const [device] = await db
      .update(devices)
      .set(updateData)
      .where(eq(devices.id, id))
      .returning();
    return device || undefined;
  }

  async getApp(id: number): Promise<App | undefined> {
    const [app] = await db.select().from(apps).where(eq(apps.id, id));
    return app || undefined;
  }

  async getAppByPackageName(packageName: string): Promise<App | undefined> {
    const [app] = await db.select().from(apps).where(eq(apps.packageName, packageName));
    return app || undefined;
  }

  async getAllApps(): Promise<App[]> {
    return await db.select().from(apps);
  }

  async getPopularApps(): Promise<App[]> {
    return await db.select().from(apps).limit(10);
  }

  async createApp(insertApp: InsertApp): Promise<App> {
    const appData = {
      ...insertApp,
      requiredFeatures: Array.isArray(insertApp.requiredFeatures) ? insertApp.requiredFeatures as string[] : [],
      permissions: Array.isArray(insertApp.permissions) ? insertApp.permissions as string[] : [],
      iconUrl: insertApp.iconUrl || null
    };

    const [app] = await db
      .insert(apps)
      .values([appData])
      .returning();
    return app;
  }

  async getCompatibilityCheck(id: number): Promise<CompatibilityCheck | undefined> {
    const [check] = await db.select().from(compatibilityChecks).where(eq(compatibilityChecks.id, id));
    return check || undefined;
  }

  async getCompatibilityChecksByUserId(userId: number): Promise<CompatibilityCheck[]> {
    return await db
      .select()
      .from(compatibilityChecks)
      .where(eq(compatibilityChecks.userId, userId));
  }

  async createCompatibilityCheck(insertCheck: InsertCompatibilityCheck): Promise<CompatibilityCheck> {
    const checkData = {
      ...insertCheck,
      userId: insertCheck.userId || null,
      deviceId: insertCheck.deviceId || null,
      appId: insertCheck.appId || null,
      issues: Array.isArray(insertCheck.issues) ? insertCheck.issues as string[] : [],
      suggestions: Array.isArray(insertCheck.suggestions) ? insertCheck.suggestions as string[] : [],
      checkedAt: new Date()
    };

    const [check] = await db
      .insert(compatibilityChecks)
      .values([checkData])
      .returning();
    return check;
  }

  async getSavedFixesByUserId(userId: number): Promise<SavedFix[]> {
    return await db
      .select()
      .from(savedFixes)
      .where(eq(savedFixes.userId, userId));
  }

  async createSavedFix(insertFix: InsertSavedFix): Promise<SavedFix> {
    const [fix] = await db
      .insert(savedFixes)
      .values([insertFix])
      .returning();
    return fix;
  }

  async deleteSavedFix(id: number): Promise<boolean> {
    const result = await db
      .delete(savedFixes)
      .where(eq(savedFixes.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async updateApp(id: number, appData: Partial<InsertApp>): Promise<App | undefined> {
    const [app] = await db
      .update(apps)
      .set(appData)
      .where(eq(apps.id, id))
      .returning();
    return app || undefined;
  }
}

export const storage = new DatabaseStorage();
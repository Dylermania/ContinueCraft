
#!/bin/bash

echo "🚀 Building CompatHub Mobile APK (Simple Method)..."

# Step 1: Build the web application
echo "📦 Building web application..."
npm run build

if [ $? -ne 0 ]; then
    echo "❌ Web build failed!"
    exit 1
fi

# Step 2: Copy web assets to native
echo "📋 Copying assets to native projects..."
npx cap copy

# Step 3: Sync native dependencies  
echo "🔄 Syncing native dependencies..."
npx cap sync

# Step 4: Try building with Capacitor CLI
echo "🏗️  Building APK with Capacitor..."
npx cap build android

if [ $? -eq 0 ]; then
    echo "✅ APK built successfully!"
    
    # Find and copy the APK
    APK_PATH=$(find android -name "*.apk" -type f | head -1)
    if [ -n "$APK_PATH" ]; then
        cp "$APK_PATH" ./CompatHub-debug.apk
        echo "📱 APK ready for download: CompatHub-debug.apk"
        echo "📊 APK Size: $(du -h CompatHub-debug.apk | cut -f1)"
        
        echo "✅ Build complete!"
        echo "📁 APK Location: ./CompatHub-debug.apk"
    else
        echo "❌ Could not find APK file"
        exit 1
    fi
else
    echo "❌ APK build failed!"
    exit 1
fi

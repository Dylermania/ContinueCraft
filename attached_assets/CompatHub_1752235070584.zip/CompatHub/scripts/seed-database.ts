import { db } from "../server/db";
import { apps, users } from "../shared/schema";

async function seedDatabase() {
  console.log("🌱 Seeding database with sample data...");
  
  try {
    // Create a sample user
    const [user] = await db.insert(users).values([{
      username: "demo_user",
      email: "demo@compathub.com"
    }]).returning();
    
    // Seed popular apps
    const popularApps = [
      {
        name: "Genshin Impact",
        packageName: "com.miHoYo.GenshinImpact",
        version: "4.3.0",
        category: "Games",
        minSdkVersion: 26,
        targetSdkVersion: 34,
        requiredRam: 4096,
        requiredStorage: 18000,
        requiredFeatures: ["vulkan", "opengl"],
        permissions: ["CAMERA", "MICROPHONE", "STORAGE", "NETWORK"],
        iconUrl: null
      },
      {
        name: "PUBG Mobile",
        packageName: "com.tencent.ig",
        version: "2.9.0",
        category: "Games",
        minSdkVersion: 21,
        targetSdkVersion: 33,
        requiredRam: 3072,
        requiredStorage: 5000,
        requiredFeatures: ["opengl"],
        permissions: ["CAMERA", "MICROPHONE", "LOCATION", "STORAGE"],
        iconUrl: null
      },
      {
        name: "Call of Duty Mobile",
        packageName: "com.activision.callofduty.shooter",
        version: "1.0.42",
        category: "Games",
        minSdkVersion: 23,
        targetSdkVersion: 33,
        requiredRam: 2048,
        requiredStorage: 4000,
        requiredFeatures: ["opengl"],
        permissions: ["MICROPHONE", "STORAGE", "NETWORK"],
        iconUrl: null
      },
      {
        name: "Instagram",
        packageName: "com.instagram.android",
        version: "308.0.0",
        category: "Social",
        minSdkVersion: 21,
        targetSdkVersion: 34,
        requiredRam: 1024,
        requiredStorage: 500,
        requiredFeatures: [],
        permissions: ["CAMERA", "MICROPHONE", "STORAGE", "CONTACTS"],
        iconUrl: null
      },
      {
        name: "TikTok",
        packageName: "com.zhiliaoapp.musically",
        version: "32.8.4",
        category: "Social",
        minSdkVersion: 21,
        targetSdkVersion: 33,
        requiredRam: 2048,
        requiredStorage: 1000,
        requiredFeatures: [],
        permissions: ["CAMERA", "MICROPHONE", "STORAGE", "LOCATION"],
        iconUrl: null
      },
      {
        name: "WhatsApp",
        packageName: "com.whatsapp",
        version: "2.23.25.84",
        category: "Communication",
        minSdkVersion: 19,
        targetSdkVersion: 33,
        requiredRam: 512,
        requiredStorage: 200,
        requiredFeatures: [],
        permissions: ["CAMERA", "MICROPHONE", "CONTACTS", "STORAGE"],
        iconUrl: null
      },
      {
        name: "Netflix",
        packageName: "com.netflix.mediaclient",
        version: "8.94.0",
        category: "Entertainment",
        minSdkVersion: 21,
        targetSdkVersion: 33,
        requiredRam: 1024,
        requiredStorage: 300,
        requiredFeatures: ["widevine"],
        permissions: ["STORAGE", "NETWORK"],
        iconUrl: null
      },
      {
        name: "Spotify",
        packageName: "com.spotify.music",
        version: "8.8.96.560",
        category: "Music",
        minSdkVersion: 21,
        targetSdkVersion: 33,
        requiredRam: 512,
        requiredStorage: 150,
        requiredFeatures: [],
        permissions: ["STORAGE", "NETWORK", "MICROPHONE"],
        iconUrl: null
      },
      {
        name: "YouTube",
        packageName: "com.google.android.youtube",
        version: "18.48.39",
        category: "Video",
        minSdkVersion: 21,
        targetSdkVersion: 34,
        requiredRam: 1024,
        requiredStorage: 250,
        requiredFeatures: [],
        permissions: ["CAMERA", "MICROPHONE", "STORAGE"],
        iconUrl: null
      },
      {
        name: "Discord",
        packageName: "com.discord",
        version: "200.15",
        category: "Communication",
        minSdkVersion: 21,
        targetSdkVersion: 33,
        requiredRam: 1024,
        requiredStorage: 200,
        requiredFeatures: [],
        permissions: ["MICROPHONE", "CAMERA", "STORAGE"],
        iconUrl: null
      }
    ];
    
    await db.insert(apps).values(popularApps);
    
    console.log("✅ Database seeded successfully!");
    console.log(`📱 Added ${popularApps.length} popular apps`);
    console.log(`👤 Created demo user: ${user.username}`);
    
  } catch (error) {
    console.error("❌ Failed to seed database:", error);
    process.exit(1);
  }
}

// Run seeding if called directly
if (import.meta.url === `file://${process.argv[1]}`) {
  seedDatabase();
}

export { seedDatabase };
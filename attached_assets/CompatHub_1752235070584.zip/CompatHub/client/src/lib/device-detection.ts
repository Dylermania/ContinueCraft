export interface DeviceSpecs {
  osVersion: string;
  cpuArchitecture: string;
  ram: number; // in MB
  gpu: string;
  storage: number; // in GB
  freeStorage: number; // in GB
  isRooted: boolean;
}

export async function detectDeviceSpecs(): Promise<DeviceSpecs> {
  // In a real React Native app, this would use actual device detection
  // For web demo, we'll simulate device detection
  
  const userAgent = navigator.userAgent;
  const memory = (navigator as any).deviceMemory || 4; // GB
  const connection = (navigator as any).connection;
  
  // Simulate device specs based on available browser APIs
  const specs: DeviceSpecs = {
    osVersion: getOSVersion(),
    cpuArchitecture: getCPUArchitecture(),
    ram: memory * 1024, // Convert to MB
    gpu: getGPUInfo(),
    storage: getStorageInfo(),
    freeStorage: getStorageInfo() * 0.6, // Assume 60% free
    isRooted: false // Can't detect on web
  };

  return specs;
}

function getOSVersion(): string {
  const userAgent = navigator.userAgent;
  
  if (userAgent.includes('Android')) {
    const match = userAgent.match(/Android (\d+(?:\.\d+)?)/);
    if (match) {
      const version = match[1];
      const apiLevel = getAPILevel(version);
      return `Android ${version} (API ${apiLevel})`;
    }
  }
  
  // Fallback for non-Android devices
  return "Android 10 (API 29)";
}

function getCPUArchitecture(): string {
  // Check for 64-bit support
  const is64Bit = navigator.userAgent.includes('x86_64') || 
                  navigator.userAgent.includes('Win64') ||
                  navigator.platform.includes('64');
  
  return is64Bit ? "arm64-v8a" : "armeabi-v7a";
}

function getGPUInfo(): string {
  try {
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
    
    if (gl) {
      const debugInfo = gl.getExtension('WEBGL_debug_renderer_info');
      if (debugInfo) {
        const renderer = gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL);
        
        // Map common GPU names to mobile equivalents
        if (renderer.includes('NVIDIA')) return "Adreno 640";
        if (renderer.includes('AMD')) return "Mali-G76";
        if (renderer.includes('Intel')) return "Adreno 610";
      }
    }
  } catch (e) {
    // Fallback
  }
  
  return "Adreno 610";
}

function getStorageInfo(): number {
  // Estimate storage based on device capabilities
  const memory = (navigator as any).deviceMemory || 4;
  
  // Rough mapping: more RAM usually means more storage
  if (memory >= 8) return 128;
  if (memory >= 6) return 64;
  if (memory >= 4) return 32;
  return 16;
}

function getAPILevel(androidVersion: string): number {
  const versionMap: { [key: string]: number } = {
    "14": 34,
    "13": 33,
    "12": 31,
    "11": 30,
    "10": 29,
    "9": 28,
    "8.1": 27,
    "8.0": 26,
    "7.1": 25,
    "7.0": 24
  };
  
  return versionMap[androidVersion] || 29;
}

export interface APKInfo {
  name: string;
  packageName: string;
  version: string;
  minSdkVersion: number;
  targetSdkVersion: number;
  requiredRam: number; // in MB
  requiredStorage: number; // in MB
  requiredFeatures: string[];
  permissions: string[];
}

export async function parseAPKFile(file: File): Promise<APKInfo> {
  // In a real implementation, this would parse the actual APK manifest
  // For demo purposes, we'll analyze the filename and return mock data
  
  const fileName = file.name.toLowerCase();
  
  // Return different mock data based on filename patterns
  if (fileName.includes('genshin') || fileName.includes('impact')) {
    return {
      name: "Genshin Impact",
      packageName: "com.mihoyo.genshin",
      version: "4.2.0",
      minSdkVersion: 26,
      targetSdkVersion: 33,
      requiredRam: 4096,
      requiredStorage: 8000,
      requiredFeatures: ["vulkan", "opengl_es_3", "gyroscope"],
      permissions: ["INTERNET", "WRITE_EXTERNAL_STORAGE", "CAMERA", "RECORD_AUDIO"]
    };
  }
  
  if (fileName.includes('cod') || fileName.includes('duty')) {
    return {
      name: "Call of Duty Mobile",
      packageName: "com.activision.callofduty.shooter",
      version: "1.0.34",
      minSdkVersion: 21,
      targetSdkVersion: 30,
      requiredRam: 3072,
      requiredStorage: 4000,
      requiredFeatures: ["accelerometer", "gyroscope", "opengl_es_2"],
      permissions: ["INTERNET", "ACCESS_NETWORK_STATE", "RECORD_AUDIO", "VIBRATE"]
    };
  }
  
  if (fileName.includes('photoshop') || fileName.includes('adobe')) {
    return {
      name: "Adobe Photoshop",
      packageName: "com.adobe.photoshop",
      version: "23.0.0",
      minSdkVersion: 24,
      targetSdkVersion: 31,
      requiredRam: 2048,
      requiredStorage: 1500,
      requiredFeatures: ["camera", "touchscreen"],
      permissions: ["CAMERA", "READ_EXTERNAL_STORAGE", "WRITE_EXTERNAL_STORAGE"]
    };
  }
  
  // Generic app for unknown files
  return {
    name: file.name.replace('.apk', ''),
    packageName: `com.unknown.${file.name.replace('.apk', '').toLowerCase()}`,
    version: "1.0.0",
    minSdkVersion: 21,
    targetSdkVersion: 30,
    requiredRam: 2048,
    requiredStorage: 1000,
    requiredFeatures: ["touchscreen"],
    permissions: ["INTERNET"]
  };
}

export function validateAPKFile(file: File): boolean {
  return file.name.toLowerCase().endsWith('.apk') && file.size > 0;
}

export default function Particles() {
  return (
    <div className="particles fixed inset-0 pointer-events-none z-0">
      <div className="particle w-3 h-3" style={{ left: '15%', top: '25%' }}></div>
      <div className="particle w-2 h-2" style={{ left: '75%', top: '75%' }}></div>
      <div className="particle w-4 h-4" style={{ left: '55%', top: '45%' }}></div>
      <div className="particle w-2 h-2" style={{ left: '25%', top: '65%' }}></div>
      <div className="particle w-1 h-1" style={{ left: '85%', top: '15%' }}></div>
      <div className="particle w-3 h-3" style={{ left: '45%', top: '85%' }}></div>
      <div className="particle w-2 h-2" style={{ left: '5%', top: '55%' }}></div>
      <div className="particle w-1 h-1" style={{ left: '95%', top: '35%' }}></div>
    </div>
  );
}

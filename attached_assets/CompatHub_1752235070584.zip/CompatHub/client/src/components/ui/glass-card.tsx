import { cn } from "@/lib/utils";
import { ReactNode } from "react";

interface GlassCardProps {
  children: ReactNode;
  className?: string;
  variant?: 'light' | 'dark';
  onClick?: () => void;
}

export default function GlassCard({ 
  children, 
  className, 
  variant = 'light',
  onClick 
}: GlassCardProps) {
  return (
    <div 
      className={cn(
        "rounded-2xl p-6 transition-all duration-300",
        variant === 'light' ? "glass" : "glass-dark",
        onClick && "cursor-pointer hover:bg-opacity-20",
        className
      )}
      onClick={onClick}
    >
      {children}
    </div>
  );
}

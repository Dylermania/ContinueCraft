import { ArrowLeft, Globe, Moon, BarChart3, Bug, Code, Trash2, Layers } from "lucide-react";
import { useState } from "react";
import { useLocation } from "wouter";
import StatusBar from "@/components/ui/status-bar";
import GlassCard from "@/components/ui/glass-card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";

export default function Settings() {
  const [, navigate] = useLocation();
  const [analytics, setAnalytics] = useState(false);
  const [crashReports, setCrashReports] = useState(true);
  const [developerMode, setDeveloperMode] = useState(false);
  const { toast } = useToast();

  const handleClearCache = () => {
    toast({
      title: "Cache Cleared",
      description: "All saved data has been removed.",
    });
  };

  return (
    <div className="bg-gray-900 min-h-screen relative z-10">
      {/* Header */}
      <div className="flex items-center justify-between p-6">
        <button 
          onClick={() => navigate("/home")} 
          className="p-2 rounded-xl glass-dark"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="text-xl font-bold">Settings</h1>
        <div></div>
      </div>
      
      {/* Settings Groups */}
      <div className="px-6 space-y-6">
        {/* General Settings */}
        <div>
          <h3 className="text-lg font-semibold mb-4">General</h3>
          <div className="space-y-3">
            <GlassCard variant="dark">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center">
                    <Globe className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h4 className="font-semibold">Language</h4>
                    <p className="text-gray-400 text-sm">English</p>
                  </div>
                </div>
                <div className="text-gray-400">→</div>
              </div>
            </GlassCard>
            
            <GlassCard variant="dark">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-secondary rounded-xl flex items-center justify-center">
                    <Moon className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h4 className="font-semibold">Dark Mode</h4>
                    <p className="text-gray-400 text-sm">Always enabled</p>
                  </div>
                </div>
                <Switch checked disabled />
              </div>
            </GlassCard>
          </div>
        </div>
        
        {/* Privacy Settings */}
        <div>
          <h3 className="text-lg font-semibold mb-4">Privacy & Data</h3>
          <div className="space-y-3">
            <GlassCard variant="dark">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-accent rounded-xl flex items-center justify-center">
                    <BarChart3 className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h4 className="font-semibold">Analytics</h4>
                    <p className="text-gray-400 text-sm">Help improve CompatHub</p>
                  </div>
                </div>
                <Switch 
                  checked={analytics} 
                  onCheckedChange={setAnalytics}
                />
              </div>
            </GlassCard>
            
            <GlassCard variant="dark">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-warning rounded-xl flex items-center justify-center">
                    <Bug className="w-5 h-5 text-gray-900" />
                  </div>
                  <div>
                    <h4 className="font-semibold">Crash Reports</h4>
                    <p className="text-gray-400 text-sm">Send crash logs</p>
                  </div>
                </div>
                <Switch 
                  checked={crashReports} 
                  onCheckedChange={setCrashReports}
                />
              </div>
            </GlassCard>
          </div>
        </div>
        
        {/* Advanced Settings */}
        <div>
          <h3 className="text-lg font-semibold mb-4">Advanced</h3>
          <div className="space-y-3">
            <GlassCard variant="dark">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-destructive rounded-xl flex items-center justify-center">
                    <Code className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h4 className="font-semibold">Developer Mode</h4>
                    <p className="text-gray-400 text-sm">Show advanced diagnostics</p>
                  </div>
                </div>
                <Switch 
                  checked={developerMode} 
                  onCheckedChange={setDeveloperMode}
                />
              </div>
            </GlassCard>
            
            <GlassCard variant="dark">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-gray-600 rounded-xl flex items-center justify-center">
                    <Trash2 className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h4 className="font-semibold">Clear Cache</h4>
                    <p className="text-gray-400 text-sm">Remove all saved data</p>
                  </div>
                </div>
                <Button 
                  onClick={handleClearCache}
                  variant="destructive"
                  size="sm"
                >
                  Clear
                </Button>
              </div>
            </GlassCard>
          </div>
        </div>
        
        {/* About */}
        <div className="pb-20">
          <h3 className="text-lg font-semibold mb-4">About</h3>
          <GlassCard variant="dark">
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 glass rounded-2xl flex items-center justify-center">
                <Layers className="w-8 h-8 text-primary" />
              </div>
              <h4 className="font-bold text-lg mb-2">CompatHub</h4>
              <p className="text-gray-400 text-sm mb-2">Version 1.0.0</p>
              <p className="text-gray-400 text-xs">© 2024 CompatHub Team</p>
            </div>
          </GlassCard>
        </div>
      </div>
    </div>
  );
}

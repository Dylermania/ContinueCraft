import { useEffect } from "react";
import { useLocation } from "wouter";
import { Layers } from "lucide-react";

export default function SplashScreen() {
  const [, navigate] = useLocation();

  useEffect(() => {
    const timer = setTimeout(() => {
      navigate("/home");
    }, 3000);

    return () => clearTimeout(timer);
  }, [navigate]);

  return (
    <div className="gradient-bg flex flex-col items-center justify-center min-h-screen p-8 relative z-10">
      <div className="text-center">
        <div className="mb-8">
          <div className="w-24 h-24 mx-auto glass rounded-3xl flex items-center justify-center pulse-animation glow-animation">
            <Layers className="w-12 h-12 text-white" />
          </div>
        </div>
        <h1 className="text-4xl font-bold mb-4 text-white">CompatHub</h1>
        <p className="text-xl text-gray-200 mb-8">"Run what your phone says you can't."</p>
        <div className="w-32 mx-auto">
          <div className="bg-white bg-opacity-20 rounded-full h-2 overflow-hidden">
            <div className="bg-white h-full rounded-full animate-pulse w-3/4"></div>
          </div>
        </div>
      </div>
    </div>
  );
}

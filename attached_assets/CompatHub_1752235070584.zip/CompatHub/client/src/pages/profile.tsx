import { ArrowLeft, User, Settings, Bookmark } from "lucide-react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import StatusBar from "@/components/ui/status-bar";
import GlassCard from "@/components/ui/glass-card";
import type { CompatibilityCheck, App } from "@shared/schema";

export default function Profile() {
  const [, navigate] = useLocation();

  const { data: compatibilityHistory } = useQuery({
    queryKey: ["/api/compatibility/history/1"], // Mock user ID
  });

  const { data: savedFixes } = useQuery({
    queryKey: ["/api/fixes/1"], // Mock user ID
  });

  return (
    <div className="bg-gray-900 min-h-screen relative z-10">
      {/* Header */}
      <div className="flex items-center justify-between p-6">
        <button 
          onClick={() => navigate("/home")} 
          className="p-2 rounded-xl glass-dark"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="text-xl font-bold">My Apps</h1>
        <div></div>
      </div>
      
      {/* Profile Section */}
      <div className="px-6 mb-6">
        <GlassCard variant="light">
          <div className="flex items-center space-x-4">
            <div className="w-16 h-16 bg-primary rounded-2xl flex items-center justify-center">
              <User className="w-8 h-8 text-white" />
            </div>
            <div className="flex-1">
              <h3 className="text-xl font-bold">Nathan</h3>
              <p className="text-gray-400">nathan@example.com</p>
            </div>
            <button 
              onClick={() => navigate("/settings")} 
              className="p-2 rounded-xl glass-dark"
            >
              <Settings className="w-5 h-5" />
            </button>
          </div>
        </GlassCard>
      </div>
      
      {/* Device Summary */}
      <div className="px-6 mb-6">
        <GlassCard variant="dark">
          <h3 className="font-semibold text-lg mb-4">My Device</h3>
          <div className="grid grid-cols-2 gap-4">
            <div className="text-center">
              <p className="text-2xl font-bold text-primary">10</p>
              <p className="text-gray-400 text-sm">Android Version</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-secondary">2.5GB</p>
              <p className="text-gray-400 text-sm">RAM</p>
            </div>
          </div>
        </GlassCard>
      </div>
      
      {/* Recent Compatibility Checks */}
      <div className="px-6 mb-6">
        <h3 className="text-lg font-semibold mb-4">Recent Checks</h3>
        <div className="space-y-3">
          {/* Mock recent checks */}
          <GlassCard variant="dark">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-primary rounded-xl flex items-center justify-center">
                <span className="text-white font-bold">G</span>
              </div>
              <div className="flex-1">
                <h4 className="font-semibold">Genshin Impact</h4>
                <p className="text-gray-400 text-sm">2 hours ago</p>
              </div>
              <span className="text-destructive text-sm font-medium">❌ Incompatible</span>
            </div>
          </GlassCard>
          
          <GlassCard variant="dark">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-secondary rounded-xl flex items-center justify-center">
                <span className="text-white font-bold">C</span>
              </div>
              <div className="flex-1">
                <h4 className="font-semibold">Call of Duty Mobile</h4>
                <p className="text-gray-400 text-sm">1 day ago</p>
              </div>
              <span className="text-accent text-sm font-medium">✅ Compatible</span>
            </div>
          </GlassCard>
          
          <GlassCard variant="dark">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-warning rounded-xl flex items-center justify-center">
                <span className="text-gray-900 font-bold">A</span>
              </div>
              <div className="flex-1">
                <h4 className="font-semibold">Adobe Photoshop</h4>
                <p className="text-gray-400 text-sm">3 days ago</p>
              </div>
              <span className="text-warning text-sm font-medium">⚠️ Partial</span>
            </div>
          </GlassCard>
        </div>
      </div>
      
      {/* Saved Fixes */}
      <div className="px-6 pb-20">
        <h3 className="text-lg font-semibold mb-4">Saved Fixes</h3>
        <div className="space-y-3">
          <GlassCard variant="dark">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-semibold">Genshin Impact Lite</h4>
                <p className="text-gray-400 text-sm">Alternative version</p>
              </div>
              <Bookmark className="w-5 h-5 text-primary" />
            </div>
          </GlassCard>
          <GlassCard variant="dark">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-semibold">PUBG Graphics Fix</h4>
                <p className="text-gray-400 text-sm">Community patch</p>
              </div>
              <Bookmark className="w-5 h-5 text-primary" />
            </div>
          </GlassCard>
        </div>
      </div>
    </div>
  );
}

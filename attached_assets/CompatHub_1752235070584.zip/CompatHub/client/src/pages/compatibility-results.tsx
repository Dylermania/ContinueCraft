import React from "react";
import { ArrowLeft, CheckCircle, XCircle, AlertTriangle } from "lucide-react";
import { useLocation, useRoute } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import StatusBar from "@/components/ui/status-bar";
import GlassCard from "@/components/ui/glass-card";
import { Button } from "@/components/ui/button";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { App, CompatibilityCheck } from "@shared/schema";

export default function CompatibilityResults() {
  const [, navigate] = useLocation();
  const [, params] = useRoute("/results/:appId");
  const appId = parseInt(params?.appId || "1");
  const { toast } = useToast();

  const { data: app } = useQuery<App>({
    queryKey: [`/api/apps/${appId}`],
  });

  const checkCompatibilityMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/compatibility/check", {
        userId: 1, // Mock user ID
        deviceId: 1, // Mock device ID
        appId: appId
      });
      return response.json();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to check compatibility.",
        variant: "destructive",
      });
    },
  });

  const startEmulationMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/emulation/start", {
        userId: 1,
        deviceId: 1,
        appId: appId
      });
      return response.json();
    },
    onSuccess: (session) => {
      toast({
        title: "Emulation Started",
        description: `Running ${app?.name} in ${session.sessionType} mode`,
      });
      navigate("/container");
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to start emulation.",
        variant: "destructive",
      });
    },
  });

  const compatibilityResult = checkCompatibilityMutation.data as CompatibilityCheck | undefined;

  // Auto-run compatibility check when component mounts
  React.useEffect(() => {
    if (app && !checkCompatibilityMutation.data && !checkCompatibilityMutation.isPending) {
      checkCompatibilityMutation.mutate();
    }
  }, [app, checkCompatibilityMutation]);

  const getStatusIcon = () => {
    if (!compatibilityResult) return null;
    
    if (compatibilityResult.isCompatible) {
      return <CheckCircle className="w-8 h-8 text-green-400" />;
    } else if (compatibilityResult.compatibilityScore > 50) {
      return <AlertTriangle className="w-8 h-8 text-warning" />;
    } else {
      return <XCircle className="w-8 h-8 text-destructive" />;
    }
  };

  const getStatusText = () => {
    if (!compatibilityResult) return "Checking...";
    
    if (compatibilityResult.isCompatible) {
      return "Compatible";
    } else if (compatibilityResult.compatibilityScore > 50) {
      return "Partially Compatible";
    } else {
      return "Not Compatible";
    }
  };

  const getStatusColor = () => {
    if (!compatibilityResult) return "text-gray-400";
    
    if (compatibilityResult.isCompatible) {
      return "text-green-400";
    } else if (compatibilityResult.compatibilityScore > 50) {
      return "text-warning";
    } else {
      return "text-destructive";
    }
  };

  if (!app) {
    return (
      <div className="bg-gray-900 min-h-screen flex items-center justify-center">
        <div className="text-gray-400">Loading app details...</div>
      </div>
    );
  }

  return (
    <div className="bg-gray-900 min-h-screen relative z-10">
      {/* Header */}
      <div className="flex items-center justify-between p-6">
        <button 
          onClick={() => navigate("/selector")} 
          className="p-2 rounded-xl glass-dark"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="text-xl font-bold">Compatibility Check</h1>
        <div></div>
      </div>
      
      {/* App Info */}
      <div className="px-6 mb-6">
        <GlassCard variant="light">
          <div className="flex items-center space-x-4 mb-4">
            {app.iconUrl ? (
              <img 
                src={app.iconUrl} 
                alt={app.name}
                className="w-16 h-16 rounded-2xl object-cover"
              />
            ) : (
              <div className="w-16 h-16 bg-primary rounded-2xl flex items-center justify-center">
                <span className="text-white font-bold text-xl">
                  {app.name.charAt(0)}
                </span>
              </div>
            )}
            <div>
              <h3 className="text-xl font-bold">{app.name}</h3>
              <p className="text-gray-400">Version {app.version}</p>
            </div>
          </div>
          
          {/* Compatibility Status */}
          <div className={`border rounded-2xl p-6 text-center shadow-lg ${
            compatibilityResult?.isCompatible 
              ? 'bg-green-600/20 border-green-600' 
              : compatibilityResult?.compatibilityScore > 50
              ? 'bg-warning/20 border-warning'
              : 'bg-destructive/20 border-destructive'
          }`}>
            <div className="flex justify-center mb-2">
              {getStatusIcon()}
            </div>
            <h4 className={`font-semibold text-lg ${getStatusColor()}`}>
              {getStatusText()}
            </h4>
            <p className="text-gray-300 text-sm">
              {compatibilityResult?.isCompatible 
                ? "Your device meets all requirements"
                : "Your device doesn't meet some requirements"}
            </p>
            {compatibilityResult && (
              <p className="text-gray-400 text-xs mt-2">
                Compatibility Score: {compatibilityResult.compatibilityScore}%
              </p>
            )}
          </div>
        </GlassCard>
      </div>
      
      {/* Detailed Report */}
      {compatibilityResult && (
        <div className="px-6 mb-6">
          <h3 className="text-lg font-semibold mb-4">Compatibility Report</h3>
          <div className="space-y-3">
            <GlassCard variant="dark">
              <div className="flex justify-between items-center">
                <div>
                  <span className="text-gray-400 text-sm">RAM Required</span>
                  <p className="font-semibold">{(app.requiredRam / 1024).toFixed(1)} GB</p>
                </div>
                <div className="text-right">
                  <span className="text-gray-400 text-sm">Your Device</span>
                  <p className={`font-semibold ${
                    compatibilityResult.issues.includes("RAM") ? "text-destructive" : "text-green-400"
                  }`}>
                    2.5 GB {compatibilityResult.issues.includes("RAM") ? "❌" : "✅"}
                  </p>
                </div>
              </div>
            </GlassCard>
            
            <GlassCard variant="dark">
              <div className="flex justify-between items-center">
                <div>
                  <span className="text-gray-400 text-sm">Android Version</span>
                  <p className="font-semibold">API {app.minSdkVersion}+</p>
                </div>
                <div className="text-right">
                  <span className="text-gray-400 text-sm">Your Device</span>
                  <p className={`font-semibold ${
                    compatibilityResult.issues.includes("Android Version") ? "text-destructive" : "text-green-400"
                  }`}>
                    API 29 {compatibilityResult.issues.includes("Android Version") ? "❌" : "✅"}
                  </p>
                </div>
              </div>
            </GlassCard>
            
            <GlassCard variant="dark">
              <div className="flex justify-between items-center">
                <div>
                  <span className="text-gray-400 text-sm">Storage Required</span>
                  <p className="font-semibold">{(app.requiredStorage / 1024).toFixed(1)} GB</p>
                </div>
                <div className="text-right">
                  <span className="text-gray-400 text-sm">Available</span>
                  <p className={`font-semibold ${
                    compatibilityResult.issues.includes("Storage") ? "text-destructive" : "text-green-400"
                  }`}>
                    42 GB {compatibilityResult.issues.includes("Storage") ? "❌" : "✅"}
                  </p>
                </div>
              </div>
            </GlassCard>

            <GlassCard variant="dark">
              <div className="flex justify-between items-center">
                <div>
                  <span className="text-gray-400 text-sm">GPU Support</span>
                  <p className="font-semibold">{app.requiredFeatures.includes("vulkan") ? "Vulkan API" : "OpenGL ES"}</p>
                </div>
                <div className="text-right">
                  <span className="text-gray-400 text-sm">Your Device</span>
                  <p className={`font-semibold ${
                    compatibilityResult.issues.includes("GPU") ? "text-warning" : "text-green-400"
                  }`}>
                    {compatibilityResult.issues.includes("GPU") ? "Limited ⚠️" : "Supported ✅"}
                  </p>
                </div>
              </div>
            </GlassCard>
          </div>
        </div>
      )}
      
      {/* Action Buttons */}
      {compatibilityResult && (
        <div className="px-6 space-y-3">
          {!compatibilityResult.isCompatible && (
            <>
              <Button 
                onClick={() => startEmulationMutation.mutate()}
                disabled={startEmulationMutation.isPending}
                className="w-full bg-primary hover:bg-primary/80 rounded-button py-4"
              >
                <span className="mr-2">🚀</span>
                {startEmulationMutation.isPending ? "Starting..." : "Run in CompatHub"}
              </Button>
              <Button 
                onClick={() => navigate("/emulation")}
                variant="outline"
                className="w-full glass-dark rounded-button py-4 border-gray-600"
              >
                <span className="mr-2">🔧</span>
                Emulation Options
              </Button>
              <Button 
                onClick={() => navigate("/suggestions")}
                variant="outline"
                className="w-full glass-dark rounded-button py-4 border-gray-600"
              >
                <span className="mr-2">💡</span>
                View Fix Suggestions
              </Button>
            </>
          )}
          
          {compatibilityResult.isCompatible && (
            <>
              <Button 
                className="w-full status-compatible rounded-button py-4"
              >
                <span className="mr-2">⬇️</span>
                Install App
              </Button>
              <Button 
                onClick={() => startEmulationMutation.mutate()}
                disabled={startEmulationMutation.isPending}
                variant="outline"
                className="w-full glass-dark rounded-button py-4 border-gray-600"
              >
                <span className="mr-2">🚀</span>
                {startEmulationMutation.isPending ? "Starting..." : "Run in CompatHub Anyway"}
              </Button>
            </>
          )}
        </div>
      )}
    </div>
  );
}

import React from "react";
import { ArrowLeft, Play, Pause, Square, Settings, Monitor } from "lucide-react";
import { useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import StatusBar from "@/components/ui/status-bar";
import GlassCard from "@/components/ui/glass-card";
import { Button } from "@/components/ui/button";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function VirtualContainer() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [activeSessionId, setActiveSessionId] = React.useState<string | null>(null);

  // Get user's active sessions
  const { data: sessions } = useQuery({
    queryKey: [`/api/emulation/sessions/1`],
    refetchInterval: 5000, // Refresh every 5 seconds
  });

  // Get current session details
  const { data: currentSession } = useQuery({
    queryKey: [`/api/emulation/session/${activeSessionId}`],
    enabled: !!activeSessionId,
    refetchInterval: 2000,
  });

  React.useEffect(() => {
    if (sessions && sessions.length > 0 && !activeSessionId) {
      setActiveSessionId(sessions[0].id);
    }
  }, [sessions, activeSessionId]);

  const controlSessionMutation = useMutation({
    mutationFn: async (action: string) => {
      if (!activeSessionId) throw new Error("No active session");
      const response = await apiRequest("POST", `/api/emulation/session/${activeSessionId}/${action}`, {});
      return response.json();
    },
    onSuccess: (_, action) => {
      toast({
        title: "Session Updated",
        description: `Session ${action}ed successfully`,
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to control session.",
        variant: "destructive",
      });
    },
  });

  const handleSessionControl = (action: string) => {
    controlSessionMutation.mutate(action);
  };

  return (
    <div className="bg-gray-900 min-h-screen relative z-10">
      {/* Container Header */}
      <div className="bg-gray-800 border-b border-gray-700 p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-3 h-3 bg-destructive rounded-full"></div>
            <div className="w-3 h-3 bg-warning rounded-full"></div>
            <div className="w-3 h-3 bg-accent rounded-full"></div>
          </div>
          <span className="text-sm text-gray-400">Virtual Android Container</span>
          <button 
            onClick={() => navigate("/emulation")}
            className="text-gray-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Mock Android Desktop */}
      <div className="flex-1 p-6 gradient-bg">
        {/* Virtual Android Status Bar */}
        <div className="bg-black bg-opacity-30 rounded-xl p-2 mb-4 text-xs text-white flex justify-between items-center">
          <span>10:41 AM</span>
          <div className="flex space-x-1">
            <div className="w-3 h-2 bg-white rounded-sm"></div>
            <div className="w-3 h-2 bg-white rounded-sm"></div>
            <div className="w-4 h-2 bg-white rounded-sm"></div>
          </div>
        </div>

        {/* Container Status */}
      <div className="px-6 mb-6">
        <GlassCard variant="light">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold">Virtual Container</h3>
            <div className="flex items-center space-x-2">
              <div className={`w-3 h-3 rounded-full ${
                currentSession?.status === 'running' ? 'bg-green-400 animate-pulse' :
                currentSession?.status === 'paused' ? 'bg-yellow-400' :
                'bg-gray-400'
              }`}></div>
              <span className={`text-sm ${
                currentSession?.status === 'running' ? 'text-green-400' :
                currentSession?.status === 'paused' ? 'text-yellow-400' :
                'text-gray-400'
              }`}>
                {currentSession?.status || 'No Session'}
              </span>
            </div>
          </div>

          {currentSession && (
            <div className="mb-4 space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Session Type:</span>
                <span className="capitalize">{currentSession.sessionType}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">RAM Allocated:</span>
                <span>{(currentSession.config.allocatedRam / 1024).toFixed(1)} GB</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">GPU Acceleration:</span>
                <span>{currentSession.config.gpuAcceleration ? 'Enabled' : 'Disabled'}</span>
              </div>
            </div>
          )}

          <div className="bg-black rounded-xl p-4 mb-4">
            <div className="flex items-center justify-center h-48 text-gray-400">
              <Monitor className="w-16 h-16 mb-2" />
              <div className="text-center">
                <p className="text-lg font-semibold">App Display</p>
                <p className="text-sm">
                  {currentSession ? `${currentSession.sessionType} emulation active` : 'No active session'}
                </p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <Button 
              onClick={() => handleSessionControl('resume')}
              disabled={!currentSession || currentSession.status === 'running' || controlSessionMutation.isPending}
              className="bg-green-600 hover:bg-green-700 rounded-button flex items-center justify-center disabled:opacity-50"
            >
              <Play className="w-4 h-4" />
            </Button>
            <Button 
              onClick={() => handleSessionControl('pause')}
              disabled={!currentSession || currentSession.status !== 'running' || controlSessionMutation.isPending}
              className="bg-yellow-600 hover:bg-yellow-700 rounded-button flex items-center justify-center disabled:opacity-50"
            >
              <Pause className="w-4 h-4" />
            </Button>
            <Button 
              onClick={() => handleSessionControl('stop')}
              disabled={!currentSession || controlSessionMutation.isPending}
              className="bg-red-600 hover:bg-red-700 rounded-button flex items-center justify-center disabled:opacity-50"
            >
              <Square className="w-4 h-4" />
            </Button>
          </div>
        </GlassCard>
      </div>

        {/* Virtual Desktop */}
        <GlassCard variant="light" className="min-h-96">
          <h3 className="text-center text-gray-200 mb-8">Virtual Android Desktop</h3>

          {/* App Grid */}
          <div className="grid grid-cols-4 gap-4 mb-8">
            <div className="text-center">
              <div className="w-12 h-12 bg-primary rounded-2xl mx-auto mb-2 flex items-center justify-center">
                <Gamepad2 className="w-6 h-6 text-white" />
              </div>
              <span className="text-xs text-gray-300">Genshin</span>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-gray-600 rounded-2xl mx-auto mb-2 flex items-center justify-center">
                <Settings className="w-6 h-6 text-white" />
              </div>
              <span className="text-xs text-gray-300">Settings</span>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-accent rounded-2xl mx-auto mb-2 flex items-center justify-center">
                <Store className="w-6 h-6 text-white" />
              </div>
              <span className="text-xs text-gray-300">Play Store</span>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-secondary rounded-2xl mx-auto mb-2 flex items-center justify-center">
                <Camera className="w-6 h-6 text-white" />
              </div>
              <span className="text-xs text-gray-300">Camera</span>
            </div>
          </div>

          {/* Launch Button */}
          <div className="text-center">
            <Button className="bg-primary hover:bg-primary/80 px-8 py-3 rounded-button mb-4">
              <Play className="w-4 h-4 mr-2" />
              Launch Genshin Impact
            </Button>
            <p className="text-gray-400 text-sm">App will run in this isolated environment</p>
          </div>
        </GlassCard>

        {/* Performance Monitor */}
        <GlassCard variant="dark" className="mt-4">
          <h4 className="font-semibold mb-3 text-sm">Performance Monitor</h4>
          <div className="space-y-2">
            <div className="flex justify-between text-xs">
              <span className="text-gray-400">CPU Usage</span>
              <span>45%</span>
            </div>
            <div className="w-full bg-gray-700 rounded-full h-1">
              <div className="bg-warning h-1 rounded-full" style={{ width: "45%" }}></div>
            </div>

            <div className="flex justify-between text-xs">
              <span className="text-gray-400">RAM Usage</span>
              <span>3.2/4.0 GB</span>
            </div>
            <div className="w-full bg-gray-700 rounded-full h-1">
              <div className="bg-primary h-1 rounded-full" style={{ width: "80%" }}></div>
            </div>
          </div>
        </GlassCard>
      </div>
    </div>
  );
}
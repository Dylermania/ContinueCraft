import { Smartphone, Search, History, Settings, Home } from "lucide-react";
import { useLocation } from "wouter";
import StatusBar from "@/components/ui/status-bar";
import GlassCard from "@/components/ui/glass-card";

export default function HomeScreen() {
  const [, navigate] = useLocation();

  return (
    <div className="bg-gray-900 min-h-screen relative z-10">
      <StatusBar />
      
      {/* Header */}
      <div className="px-6 pt-4 pb-8">
        <h2 className="text-2xl font-bold mb-2">Hello Nathan 👋</h2>
        <p className="text-gray-400">Ready to test an app?</p>
      </div>
      
      {/* Main Actions */}
      <div className="px-6 space-y-4">
        <GlassCard 
          variant="light" 
          onClick={() => navigate("/scan")}
          className="compatibility-card cursor-pointer hover:bg-opacity-20"
        >
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 bg-primary rounded-2xl flex items-center justify-center shadow-lg">
              <Smartphone className="w-6 h-6 text-white" />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-lg">Scan Device</h3>
              <p className="text-gray-400 text-sm">Check your phone's specs</p>
            </div>
            <div className="text-accent text-lg font-bold">→</div>
          </div>
        </GlassCard>
        
        <GlassCard 
          variant="dark" 
          onClick={() => navigate("/selector")}
          className="compatibility-card cursor-pointer hover:bg-opacity-30"
        >
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 bg-accent rounded-2xl flex items-center justify-center shadow-lg">
              <Search className="w-6 h-6 text-white" />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-lg">Check App</h3>
              <p className="text-gray-400 text-sm">Select or upload APK</p>
            </div>
            <div className="text-accent text-lg font-bold">→</div>
          </div>
        </GlassCard>
        
        <GlassCard 
          variant="dark" 
          onClick={() => navigate("/profile")}
          className="compatibility-card cursor-pointer hover:bg-opacity-30"
        >
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 bg-primary rounded-2xl flex items-center justify-center shadow-lg">
              <History className="w-6 h-6 text-white" />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-lg">My Apps</h3>
              <p className="text-gray-400 text-sm">View compatibility history</p>
            </div>
            <div className="text-accent text-lg font-bold">→</div>
          </div>
        </GlassCard>
      </div>
      
      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-1/2 transform -translate-x-1/2 w-full max-w-md glass p-4">
        <div className="flex justify-center">
          <div className="flex items-center space-x-8">
            <button className="p-3 rounded-xl bg-primary bg-opacity-20">
              <Home className="w-5 h-5 text-primary" />
            </button>
            <button 
              onClick={() => navigate("/settings")} 
              className="p-3 rounded-xl"
            >
              <Settings className="w-5 h-5 text-gray-400" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

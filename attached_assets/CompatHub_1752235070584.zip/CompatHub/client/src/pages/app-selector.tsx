import { useState, useRef } from "react";
import { ArrowLeft, Search, Upload } from "lucide-react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import StatusBar from "@/components/ui/status-bar";
import GlassCard from "@/components/ui/glass-card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { parseAPKFile, validateAPKFile } from "@/lib/apk-parser";
import { useToast } from "@/hooks/use-toast";
import type { App } from "@shared/schema";

export default function AppSelector() {
  const [, navigate] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const [uploadedApp, setUploadedApp] = useState<App | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const { data: popularApps, isLoading } = useQuery<App[]>({
    queryKey: ["/api/apps/popular"],
  });

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!validateAPKFile(file)) {
      toast({
        title: "Invalid File",
        description: "Please select a valid .apk file.",
        variant: "destructive",
      });
      return;
    }

    try {
      const apkInfo = await parseAPKFile(file);
      const app: App = {
        id: 999, // Temporary ID for uploaded app
        ...apkInfo,
        iconUrl: null
      };
      setUploadedApp(app);
      toast({
        title: "APK Analyzed",
        description: `Successfully analyzed ${apkInfo.name}`,
      });
    } catch (error) {
      toast({
        title: "Parse Error",
        description: "Failed to analyze the APK file.",
        variant: "destructive",
      });
    }
  };

  const handleAppSelect = (appId: number) => {
    navigate(`/results/${appId}`);
  };

  const filteredApps = popularApps?.filter(app =>
    app.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    app.category.toLowerCase().includes(searchQuery.toLowerCase())
  ) || [];

  return (
    <div className="bg-gray-900 min-h-screen relative z-10">
      {/* Header */}
      <div className="flex items-center justify-between p-6">
        <button 
          onClick={() => navigate("/scan")} 
          className="p-2 rounded-xl glass-dark"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="text-xl font-bold">Select App</h1>
        <div></div>
      </div>
      
      {/* Search Bar */}
      <div className="px-6 mb-6">
        <div className="glass-dark rounded-2xl p-4 flex items-center space-x-3">
          <Search className="w-5 h-5 text-gray-400" />
          <Input
            type="text"
            placeholder="Search popular apps..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="bg-transparent border-none flex-1 outline-none"
          />
        </div>
      </div>
      
      {/* Upload APK */}
      <div className="px-6 mb-6">
        <GlassCard 
          variant="light" 
          className="border-2 border-dashed border-gray-600 text-center cursor-pointer"
          onClick={() => fileInputRef.current?.click()}
        >
          <Upload className="w-8 h-8 text-gray-400 mx-auto mb-4" />
          <h3 className="font-semibold mb-2">Upload APK File</h3>
          <p className="text-gray-400 text-sm mb-4">Choose .apk file to analyze</p>
          <Button className="bg-accent hover:bg-accent/80 rounded-button text-sm">
            Choose File
          </Button>
          <input
            ref={fileInputRef}
            type="file"
            accept=".apk"
            onChange={handleFileUpload}
            className="hidden"
          />
        </GlassCard>
      </div>

      {/* Uploaded App */}
      {uploadedApp && (
        <div className="px-6 mb-6">
          <h3 className="text-lg font-semibold mb-4">Uploaded App</h3>
          <GlassCard 
            variant="dark" 
            className="compatibility-card cursor-pointer"
            onClick={() => handleAppSelect(uploadedApp.id)}
          >
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-primary rounded-xl flex items-center justify-center">
                <span className="text-white font-bold">
                  {uploadedApp.name.charAt(0)}
                </span>
              </div>
              <div className="flex-1">
                <h4 className="font-semibold">{uploadedApp.name}</h4>
                <p className="text-gray-400 text-sm">{uploadedApp.category}</p>
              </div>
              <Button className="bg-primary hover:bg-primary/80 rounded-button text-sm">
                Check
              </Button>
            </div>
          </GlassCard>
        </div>
      )}
      
      {/* Popular Apps */}
      <div className="px-6">
        <h3 className="text-lg font-semibold mb-4">Popular Apps</h3>
        {isLoading ? (
          <div className="text-center text-gray-400">Loading apps...</div>
        ) : (
          <div className="space-y-3">
            {filteredApps.map((app) => (
              <GlassCard 
                key={app.id}
                variant="dark" 
                className="compatibility-card cursor-pointer"
                onClick={() => handleAppSelect(app.id)}
              >
                <div className="flex items-center space-x-4">
                  {app.iconUrl ? (
                    <img 
                      src={app.iconUrl} 
                      alt={app.name}
                      className="w-12 h-12 rounded-xl object-cover"
                    />
                  ) : (
                    <div className="w-12 h-12 bg-primary rounded-xl flex items-center justify-center">
                      <span className="text-white font-bold">
                        {app.name.charAt(0)}
                      </span>
                    </div>
                  )}
                  <div className="flex-1">
                    <h4 className="font-semibold">{app.name}</h4>
                    <p className="text-gray-400 text-sm">{app.category}</p>
                  </div>
                  <Button className="bg-primary hover:bg-primary/80 rounded-button text-sm">
                    Check
                  </Button>
                </div>
              </GlassCard>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

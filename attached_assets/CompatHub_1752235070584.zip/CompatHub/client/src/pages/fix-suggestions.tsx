import { ArrowLeft, Feather, Laptop, Code, Users, Star } from "lucide-react";
import { useLocation } from "wouter";
import StatusBar from "@/components/ui/status-bar";
import GlassCard from "@/components/ui/glass-card";
import { Button } from "@/components/ui/button";

export default function FixSuggestions() {
  const [, navigate] = useLocation();

  return (
    <div className="bg-gray-900 min-h-screen relative z-10">
      {/* Header */}
      <div className="flex items-center justify-between p-6">
        <button 
          onClick={() => navigate("/results/1")} 
          className="p-2 rounded-xl glass-dark"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="text-xl font-bold">Fix Suggestions</h1>
        <div></div>
      </div>
      
      {/* Suggestions */}
      <div className="px-6 space-y-4">
        {/* Lite Version */}
        <GlassCard variant="light">
          <div className="flex items-center space-x-3 mb-4">
            <div className="w-10 h-10 bg-accent rounded-xl flex items-center justify-center">
              <Feather className="w-5 h-5 text-white" />
            </div>
            <h3 className="font-semibold text-lg">Try Lite Version</h3>
          </div>
          <p className="text-gray-400 text-sm mb-4">Lower system requirements, optimized for older devices</p>
          <div className="bg-accent bg-opacity-10 rounded-xl p-3 mb-4">
            <p className="text-sm"><span className="font-semibold">Genshin Impact Lite:</span> Reduced graphics, smaller download size</p>
          </div>
          <Button className="w-full bg-accent hover:bg-accent/80 rounded-button py-3">
            <span className="mr-2">⬇️</span>
            Download Lite Version
          </Button>
        </GlassCard>
        
        {/* Alternative Emulators */}
        <GlassCard variant="dark">
          <div className="flex items-center space-x-3 mb-4">
            <div className="w-10 h-10 bg-secondary rounded-xl flex items-center justify-center">
              <Laptop className="w-5 h-5 text-white" />
            </div>
            <h3 className="font-semibold text-lg">External Emulators</h3>
          </div>
          <p className="text-gray-400 text-sm mb-4">Run on PC or more powerful emulators</p>
          <div className="space-y-2">
            <div className="bg-gray-800 rounded-lg p-3 flex justify-between items-center">
              <span className="text-sm">BlueStacks (PC)</span>
              <span className="text-gray-400">→</span>
            </div>
            <div className="bg-gray-800 rounded-lg p-3 flex justify-between items-center">
              <span className="text-sm">VMOS Pro</span>
              <span className="text-gray-400">→</span>
            </div>
            <div className="bg-gray-800 rounded-lg p-3 flex justify-between items-center">
              <span className="text-sm">F1 VM</span>
              <span className="text-gray-400">→</span>
            </div>
          </div>
        </GlassCard>
        
        {/* APK Patch Preview */}
        <GlassCard variant="dark">
          <div className="flex items-center space-x-3 mb-4">
            <div className="w-10 h-10 bg-warning rounded-xl flex items-center justify-center">
              <Code className="w-5 h-5 text-gray-900" />
            </div>
            <h3 className="font-semibold text-lg">Manifest Patch</h3>
          </div>
          <p className="text-gray-400 text-sm mb-4">Proposed changes to APK manifest</p>
          <div className="bg-gray-800 rounded-lg p-3 font-mono text-xs overflow-x-auto mb-4">
            <div className="text-gray-500">// Original</div>
            <div className="text-destructive">- &lt;uses-sdk android:minSdkVersion="26" /&gt;</div>
            <div className="text-gray-500">// Patched</div>
            <div className="text-accent">+ &lt;uses-sdk android:minSdkVersion="21" /&gt;</div>
          </div>
          <Button className="w-full bg-warning hover:bg-warning/80 text-gray-900 rounded-button py-3">
            Apply Patch
          </Button>
        </GlassCard>
        
        {/* Community Tips */}
        <GlassCard variant="dark">
          <div className="flex items-center space-x-3 mb-4">
            <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center">
              <Users className="w-5 h-5 text-white" />
            </div>
            <h3 className="font-semibold text-lg">Community Tips</h3>
          </div>
          <div className="space-y-3">
            <div className="bg-gray-800 rounded-lg p-3">
              <div className="flex items-center space-x-2 mb-2">
                <span className="text-sm font-medium">@GamerDev</span>
                <div className="flex text-xs text-warning">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-3 h-3 fill-current" />
                  ))}
                </div>
              </div>
              <p className="text-sm text-gray-300">"Try lowering texture quality in game settings first"</p>
            </div>
            <div className="bg-gray-800 rounded-lg p-3">
              <div className="flex items-center space-x-2 mb-2">
                <span className="text-sm font-medium">@TechFixer</span>
                <div className="flex text-xs text-warning">
                  {[...Array(4)].map((_, i) => (
                    <Star key={i} className="w-3 h-3 fill-current" />
                  ))}
                  <Star className="w-3 h-3" />
                </div>
              </div>
              <p className="text-sm text-gray-300">"Clear cache and restart device before launching"</p>
            </div>
          </div>
        </GlassCard>
      </div>
    </div>
  );
}

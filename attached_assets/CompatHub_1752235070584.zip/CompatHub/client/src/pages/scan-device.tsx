import { useState, useEffect } from "react";
import { ArrowLeft, Smartphone } from "lucide-react";
import { useLocation } from "wouter";
import { useMutation } from "@tanstack/react-query";
import StatusBar from "@/components/ui/status-bar";
import GlassCard from "@/components/ui/glass-card";
import { Button } from "@/components/ui/button";
import { detectDeviceSpecs, type DeviceSpecs } from "@/lib/device-detection";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function ScanDevice() {
  const [, navigate] = useLocation();
  const [deviceSpecs, setDeviceSpecs] = useState<DeviceSpecs | null>(null);
  const [isScanning, setIsScanning] = useState(true);
  const { toast } = useToast();

  const saveDeviceMutation = useMutation({
    mutationFn: async (specs: DeviceSpecs) => {
      const deviceData = {
        userId: 1, // Mock user ID
        osVersion: specs.osVersion,
        cpuArchitecture: specs.cpuArchitecture,
        ram: specs.ram,
        gpu: specs.gpu,
        storage: specs.storage,
        freeStorage: specs.freeStorage,
        isRooted: specs.isRooted
      };
      
      const response = await apiRequest("POST", "/api/device", deviceData);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Device specs saved",
        description: "Your device specifications have been saved successfully.",
      });
      navigate("/selector");
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save device specifications.",
        variant: "destructive",
      });
    },
  });

  useEffect(() => {
    const scanDevice = async () => {
      try {
        await new Promise(resolve => setTimeout(resolve, 2000)); // Simulate scanning
        const specs = await detectDeviceSpecs();
        setDeviceSpecs(specs);
        setIsScanning(false);
      } catch (error) {
        toast({
          title: "Scan Error",
          description: "Failed to detect device specifications.",
          variant: "destructive",
        });
        setIsScanning(false);
      }
    };

    scanDevice();
  }, [toast]);

  const handleContinue = () => {
    if (deviceSpecs) {
      saveDeviceMutation.mutate(deviceSpecs);
    }
  };

  return (
    <div className="bg-gray-900 min-h-screen relative z-10">
      {/* Header */}
      <div className="flex items-center justify-between p-6">
        <button 
          onClick={() => navigate("/home")} 
          className="p-2 rounded-xl glass-dark"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="text-xl font-bold">Device Scan</h1>
        <div></div>
      </div>
      
      {/* Scanning Animation */}
      {isScanning && (
        <div className="px-6 mb-8">
          <GlassCard variant="light" className="text-center">
            <div className="w-20 h-20 mx-auto mb-6 relative">
              <div className="absolute inset-0 border-4 border-primary border-opacity-20 rounded-full"></div>
              <div className="absolute inset-0 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
              <Smartphone className="w-8 h-8 text-primary absolute inset-0 m-auto" />
            </div>
            <h3 className="text-lg font-semibold mb-2">Scanning your device...</h3>
            <p className="text-gray-400 text-sm">Detecting specifications</p>
          </GlassCard>
        </div>
      )}
      
      {/* Device Specs */}
      {!isScanning && deviceSpecs && (
        <>
          <div className="px-6 space-y-4">
            <GlassCard variant="dark">
              <div className="flex justify-between items-center">
                <span className="text-gray-400">OS Version</span>
                <span className="font-semibold">{deviceSpecs.osVersion}</span>
              </div>
            </GlassCard>
            
            <GlassCard variant="dark">
              <div className="flex justify-between items-center">
                <span className="text-gray-400">CPU Architecture</span>
                <span className="font-semibold">{deviceSpecs.cpuArchitecture}</span>
              </div>
            </GlassCard>
            
            <GlassCard variant="dark">
              <div className="flex justify-between items-center">
                <span className="text-gray-400">RAM</span>
                <span className="font-semibold">{(deviceSpecs.ram / 1024).toFixed(1)} GB</span>
              </div>
            </GlassCard>
            
            <GlassCard variant="dark">
              <div className="flex justify-between items-center">
                <span className="text-gray-400">GPU</span>
                <span className="font-semibold">{deviceSpecs.gpu}</span>
              </div>
            </GlassCard>
            
            <GlassCard variant="dark">
              <div className="flex justify-between items-center">
                <span className="text-gray-400">Storage</span>
                <span className="font-semibold">
                  {deviceSpecs.storage} GB ({deviceSpecs.freeStorage} GB free)
                </span>
              </div>
            </GlassCard>
            
            <GlassCard variant="dark">
              <div className="flex justify-between items-center">
                <span className="text-gray-400">Root Access</span>
                <span className={`font-semibold ${deviceSpecs.isRooted ? 'text-accent' : 'text-destructive'}`}>
                  {deviceSpecs.isRooted ? '✅ Rooted' : '❌ Not Rooted'}
                </span>
              </div>
            </GlassCard>
          </div>
          
          {/* Continue Button */}
          <div className="p-6 mt-8">
            <Button 
              onClick={handleContinue}
              disabled={saveDeviceMutation.isPending}
              className="w-full bg-primary hover:bg-primary/80 rounded-button py-4 text-lg"
            >
              {saveDeviceMutation.isPending ? "Saving..." : "Continue"}
            </Button>
          </div>
        </>
      )}
    </div>
  );
}

import { ArrowLeft, Monitor, Wrench, Cloud } from "lucide-react";
import { useLocation } from "wouter";
import StatusBar from "@/components/ui/status-bar";
import GlassCard from "@/components/ui/glass-card";
import { Button } from "@/components/ui/button";

export default function EmulationOptions() {
  const [, navigate] = useLocation();

  return (
    <div className="bg-gray-900 min-h-screen relative z-10">
      {/* Header */}
      <div className="flex items-center justify-between p-6">
        <button 
          onClick={() => navigate("/results/1")} 
          className="p-2 rounded-xl glass-dark"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="text-xl font-bold">Emulation Options</h1>
        <div></div>
      </div>
      
      {/* Options */}
      <div className="px-6 space-y-4">
        <GlassCard variant="light" className="border-2 border-primary border-opacity-50">
          <div className="flex items-center space-x-4 mb-4">
            <div className="w-12 h-12 bg-primary rounded-xl flex items-center justify-center">
              <Monitor className="w-6 h-6 text-white" />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-lg">Run in Virtual Machine</h3>
              <p className="text-gray-400 text-sm">Launch app in isolated container</p>
            </div>
          </div>
          <div className="bg-primary bg-opacity-10 rounded-xl p-3 mb-4">
            <p className="text-sm text-gray-300">Creates a virtualized Android environment with enhanced specs</p>
          </div>
          <Button 
            onClick={() => navigate("/container")}
            className="w-full bg-primary hover:bg-primary/80 rounded-button py-3"
          >
            Launch VM Container
          </Button>
        </GlassCard>
        
        <GlassCard variant="dark">
          <div className="flex items-center space-x-4 mb-4">
            <div className="w-12 h-12 bg-warning rounded-xl flex items-center justify-center">
              <Wrench className="w-6 h-6 text-gray-900" />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-lg">Patch APK</h3>
              <p className="text-gray-400 text-sm">Modify app manifest file</p>
            </div>
          </div>
          <div className="bg-warning bg-opacity-10 rounded-xl p-3 mb-4">
            <p className="text-sm text-gray-300">Attempts to lower minimum requirements in the APK</p>
          </div>
          <Button 
            onClick={() => navigate("/suggestions")}
            className="w-full bg-warning hover:bg-warning/80 text-gray-900 rounded-button py-3"
          >
            Try Patching
          </Button>
        </GlassCard>
        
        <GlassCard variant="dark" className="opacity-60">
          <div className="flex items-center space-x-4 mb-4">
            <div className="w-12 h-12 bg-gray-600 rounded-xl flex items-center justify-center">
              <Cloud className="w-6 h-6 text-white" />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-lg">Cloud Streaming</h3>
              <p className="text-gray-400 text-sm">Stream app from powerful servers</p>
            </div>
            <span className="text-xs bg-gray-700 px-2 py-1 rounded">COMING SOON</span>
          </div>
          <div className="bg-gray-600 bg-opacity-10 rounded-xl p-3 mb-4">
            <p className="text-sm text-gray-400">Run apps on cloud servers and stream to your device</p>
          </div>
          <Button 
            disabled
            className="w-full bg-gray-600 rounded-button py-3 cursor-not-allowed"
          >
            Coming Soon
          </Button>
        </GlassCard>
        
        {/* Warning Notice */}
        <div className="bg-destructive/10 border border-destructive rounded-xl p-4 mt-6">
          <div className="flex items-start space-x-3">
            <div className="w-6 h-6 bg-destructive rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
              <span className="text-white text-xs">!</span>
            </div>
            <div>
              <h4 className="font-semibold text-destructive mb-1">Important Notice</h4>
              <p className="text-gray-300 text-sm">Some apps may still crash or have reduced performance. Emulation is experimental and may not work for all applications.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

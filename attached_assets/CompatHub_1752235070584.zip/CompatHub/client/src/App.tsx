import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import SplashScreen from "@/pages/splash";
import HomeScreen from "@/pages/home";
import ScanDevice from "@/pages/scan-device";
import AppSelector from "@/pages/app-selector";
import CompatibilityResults from "@/pages/compatibility-results";
import EmulationOptions from "@/pages/emulation-options";
import VirtualContainer from "@/pages/virtual-container";
import FixSuggestions from "@/pages/fix-suggestions";
import Profile from "@/pages/profile";
import Settings from "@/pages/settings";
import Particles from "@/components/ui/particles";

function Router() {
  return (
    <div className="mobile-container">
      <Particles />
      <Switch>
        <Route path="/" component={SplashScreen} />
        <Route path="/home" component={HomeScreen} />
        <Route path="/scan" component={ScanDevice} />
        <Route path="/selector" component={AppSelector} />
        <Route path="/results/:appId" component={CompatibilityResults} />
        <Route path="/emulation" component={EmulationOptions} />
        <Route path="/container" component={VirtualContainer} />
        <Route path="/suggestions" component={FixSuggestions} />
        <Route path="/profile" component={Profile} />
        <Route path="/settings" component={Settings} />
        <Route component={NotFound} />
      </Switch>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;

# CompatHub - Mobile App Compatibility Testing Platform

## Overview

CompatHub is a mobile-first application designed to help users run apps that are normally incompatible with their device. The system creates virtual environments and compatibility layers to enable apps to run on hardware or software configurations that would otherwise be unsupported. The application follows a modern full-stack architecture with React frontend, Express backend, and PostgreSQL database.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **UI Library**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables for theming
- **State Management**: TanStack Query for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Build Tool**: Vite for fast development and optimized builds

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Database ORM**: Drizzle ORM for type-safe database operations
- **Database**: PostgreSQL (configured for Neon serverless)
- **API Pattern**: RESTful API endpoints under `/api` prefix

### Mobile-First Design
- Designed specifically for mobile devices (Android-first approach)
- Glassmorphism UI design with particle effects
- Responsive components optimized for touch interfaces
- Status bar simulation for authentic mobile experience

## Key Components

### Database Schema
The system uses five main entities:

1. **Users**: Basic user authentication and identification
2. **Devices**: Hardware specifications and capabilities
3. **Apps**: Application metadata including requirements and permissions
4. **Compatibility Checks**: Results of compatibility analysis between devices and apps
5. **Saved Fixes**: User-saved solutions and workarounds

### Core Features
1. **Device Scanning**: Automatic detection of device specifications (OS, CPU, RAM, GPU, storage)
2. **App Analysis**: Upload and analysis of APK files or selection from popular apps database
3. **Compatibility Testing**: Algorithm-based compatibility checking with scoring system
4. **Virtual Container**: Emulation environment for running incompatible apps
5. **Fix Suggestions**: Recommendations for compatibility issues including lite versions and alternative solutions

### User Flow
```
Splash Screen → Home → Device Scan → App Selection → Compatibility Results
    ↓ (if incompatible)
Emulation Options → Virtual Container / Fix Suggestions
```

## Data Flow

### Device Detection Flow
1. User initiates device scan
2. Frontend detects available device specifications using browser APIs
3. Device data is validated and stored in database
4. Specifications are used for subsequent compatibility checks

### Compatibility Analysis Flow
1. User selects or uploads an app (APK)
2. App requirements are extracted and stored
3. Device specs are compared against app requirements
4. Compatibility score (0-100) is calculated
5. Issues and suggestions are generated
6. Results are stored and presented to user

### Virtual Environment Flow
1. User selects incompatible app for emulation
2. Virtual container is configured with enhanced specifications
3. App is launched within isolated environment
4. Virtual Android desktop interface is presented

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL serverless database connection
- **drizzle-orm**: Type-safe database ORM
- **@tanstack/react-query**: Server state management
- **wouter**: Lightweight React router
- **zod**: Runtime type validation

### UI Dependencies
- **@radix-ui/***: Accessible UI primitives (30+ components)
- **tailwindcss**: Utility-first CSS framework
- **class-variance-authority**: Component variant management
- **lucide-react**: Icon library

### Development Dependencies
- **vite**: Build tool and dev server
- **typescript**: Static type checking
- **tsx**: TypeScript execution for Node.js

## Deployment Strategy

### Development Environment
- Vite dev server with HMR for frontend
- tsx for running TypeScript backend in development
- Integrated development with middleware setup

### Production Build
- Frontend: Vite builds optimized static assets to `dist/public`
- Backend: esbuild bundles server code to `dist/index.js`
- Database: Drizzle handles schema migrations to `./migrations`

### Environment Configuration
- Database connection via `DATABASE_URL` environment variable
- Separate development and production build processes
- Static file serving in production mode

### Key Architectural Decisions

1. **Mobile-First Approach**: Prioritized mobile user experience over desktop, using touch-optimized components and mobile-specific UI patterns

2. **Glassmorphism Design**: Chose modern glass-effect UI to create premium feel and visual depth, implemented via custom CSS classes

3. **Type-Safe Database**: Selected Drizzle ORM for compile-time type safety and better developer experience compared to traditional ORMs

4. **Serverless Database**: Configured for Neon PostgreSQL to enable scalable, serverless database operations

5. **Component-Based Architecture**: Used shadcn/ui and Radix UI for accessible, customizable components that maintain consistency

6. **In-Memory Storage Fallback**: Implemented memory-based storage interface to enable development without database dependency

7. **Unified TypeScript**: Shared types between frontend and backend via `shared/schema.ts` for consistency and reduced duplication
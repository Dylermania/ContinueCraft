const { exec } = require('child_process');
const fs = require('fs');
const path = require('path');

async function buildAPK() {
  console.log('🚀 Starting CompatHub APK Build Process...\n');
  
  try {
    // Step 1: Build the web app
    console.log('📦 Building web application...');
    await execCommand('npm run build');
    
    // Step 2: Initialize Capacitor if not already done
    if (!fs.existsSync('android')) {
      console.log('🔧 Initializing Capacitor...');
      await execCommand('npx cap init');
      await execCommand('npx cap add android');
    }
    
    // Step 3: Copy web assets to native projects
    console.log('📋 Copying web assets...');
    await execCommand('npx cap copy');
    
    // Step 4: Sync native dependencies
    console.log('🔄 Syncing native dependencies...');
    await execCommand('npx cap sync');
    
    // Step 5: Build APK
    console.log('🏗️  Building APK...');
    await execCommand('npx cap build android');
    
    // Step 6: Build debug APK
    console.log('📱 Generating debug APK...');
    const androidPath = path.join(__dirname, '..', 'android');
    await execCommand('./gradlew assembleDebug', { cwd: androidPath });
    
    // Step 7: Copy APK to root directory
    const apkSource = path.join(androidPath, 'app', 'build', 'outputs', 'apk', 'debug', 'app-debug.apk');
    const apkDest = path.join(__dirname, '..', 'CompatHub-debug.apk');
    
    if (fs.existsSync(apkSource)) {
      fs.copyFileSync(apkSource, apkDest);
      console.log('✅ APK built successfully!');
      console.log(`📁 Location: ${apkDest}`);
      console.log(`📊 Size: ${(fs.statSync(apkDest).size / 1024 / 1024).toFixed(2)} MB`);
    } else {
      throw new Error('APK file not found after build');
    }
    
    // Step 8: Build release APK (unsigned)
    console.log('🔒 Building release APK...');
    await execCommand('./gradlew assembleRelease', { cwd: androidPath });
    
    const releaseApkSource = path.join(androidPath, 'app', 'build', 'outputs', 'apk', 'release', 'app-release-unsigned.apk');
    const releaseApkDest = path.join(__dirname, '..', 'CompatHub-release-unsigned.apk');
    
    if (fs.existsSync(releaseApkSource)) {
      fs.copyFileSync(releaseApkSource, releaseApkDest);
      console.log('✅ Release APK built successfully!');
      console.log(`📁 Location: ${releaseApkDest}`);
      console.log(`📊 Size: ${(fs.statSync(releaseApkDest).size / 1024 / 1024).toFixed(2)} MB`);
    }
    
    console.log('\n🎉 APK Build Complete!');
    console.log('\n📋 Installation Instructions:');
    console.log('1. Enable "Unknown Sources" in Android Settings');
    console.log('2. Transfer APK to your Android device');
    console.log('3. Open file manager and tap the APK to install');
    console.log('4. Grant necessary permissions when prompted');
    
  } catch (error) {
    console.error('❌ Build failed:', error.message);
    process.exit(1);
  }
}

function execCommand(command, options = {}) {
  return new Promise((resolve, reject) => {
    console.log(`> ${command}`);
    exec(command, options, (error, stdout, stderr) => {
      if (error) {
        reject(error);
        return;
      }
      if (stdout) console.log(stdout);
      if (stderr) console.warn(stderr);
      resolve();
    });
  });
}

// Run if called directly
if (require.main === module) {
  buildAPK();
}

module.exports = { buildAPK };
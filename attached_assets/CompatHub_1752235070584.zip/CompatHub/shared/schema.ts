import { pgTable, text, serial, integer, boolean, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
});

export const devices = pgTable("devices", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  osVersion: text("os_version").notNull(),
  cpuArchitecture: text("cpu_architecture").notNull(),
  ram: integer("ram").notNull(), // in MB
  gpu: text("gpu").notNull(),
  storage: integer("storage").notNull(), // in GB
  freeStorage: integer("free_storage").notNull(), // in GB
  isRooted: boolean("is_rooted").default(false),
  lastScanned: timestamp("last_scanned").defaultNow(),
});

export const apps = pgTable("apps", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  packageName: text("package_name").notNull().unique(),
  version: text("version").notNull(),
  category: text("category").notNull(),
  minSdkVersion: integer("min_sdk_version").notNull(),
  targetSdkVersion: integer("target_sdk_version").notNull(),
  requiredRam: integer("required_ram").notNull(), // in MB
  requiredStorage: integer("required_storage").notNull(), // in MB
  requiredFeatures: jsonb("required_features").$type<string[]>().default([]),
  permissions: jsonb("permissions").$type<string[]>().default([]),
  iconUrl: text("icon_url"),
});

export const compatibilityChecks = pgTable("compatibility_checks", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  deviceId: integer("device_id").references(() => devices.id),
  appId: integer("app_id").references(() => apps.id),
  isCompatible: boolean("is_compatible").notNull(),
  compatibilityScore: integer("compatibility_score").notNull(), // 0-100
  issues: jsonb("issues").$type<string[]>().default([]),
  suggestions: jsonb("suggestions").$type<string[]>().default([]),
  checkedAt: timestamp("checked_at").defaultNow(),
});

export const savedFixes = pgTable("saved_fixes", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  appId: integer("app_id").references(() => apps.id),
  fixType: text("fix_type").notNull(), // 'lite_version', 'patch', 'emulator'
  description: text("description").notNull(),
  downloadUrl: text("download_url"),
  isBookmarked: boolean("is_bookmarked").default(true),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({ id: true });
export const insertDeviceSchema = createInsertSchema(devices).omit({ 
  id: true, 
  lastScanned: true 
});
export const insertAppSchema = createInsertSchema(apps).omit({ id: true });
export const insertCompatibilityCheckSchema = createInsertSchema(compatibilityChecks).omit({ 
  id: true, 
  checkedAt: true 
});
export const insertSavedFixSchema = createInsertSchema(savedFixes).omit({ id: true });

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Device = typeof devices.$inferSelect;
export type InsertDevice = z.infer<typeof insertDeviceSchema>;

export type App = typeof apps.$inferSelect;
export type InsertApp = z.infer<typeof insertAppSchema>;

export type CompatibilityCheck = typeof compatibilityChecks.$inferSelect;
export type InsertCompatibilityCheck = z.infer<typeof insertCompatibilityCheckSchema>;

export type SavedFix = typeof savedFixes.$inferSelect;
export type InsertSavedFix = z.infer<typeof insertSavedFixSchema>;


#!/bin/bash

echo "🚀 Building CompatHub Mobile APK..."

# Step 1: Build the web application
echo "📦 Building web application..."
npm run build

if [ $? -ne 0 ]; then
    echo "❌ Web build failed!"
    exit 1
fi

# Step 2: Copy web assets to native
echo "📋 Copying assets to native projects..."
npx cap copy

# Step 3: Sync native dependencies  
echo "🔄 Syncing native dependencies..."
npx cap sync

# Step 4: Install Gradle if not available
echo "🔧 Setting up build environment..."
if ! command -v gradle &> /dev/null; then
    echo "📥 Installing Gradle..."
    # Install Gradle using SDKMAN
    curl -s "https://get.sdkman.io" | bash
    source "$HOME/.sdkman/bin/sdkman-init.sh"
    sdk install gradle 8.1.1
    export PATH="$HOME/.sdkman/candidates/gradle/current/bin:$PATH"
fi

# Step 5: Navigate to android directory
cd android

# Step 6: Create Gradle wrapper if it doesn't exist
if [ ! -f "./gradlew" ]; then
    echo "📥 Creating Gradle wrapper..."
    gradle wrapper --gradle-version 8.1.1 --distribution-type bin
fi

# Make gradlew executable
chmod +x ./gradlew

# Step 7: Clean and build debug APK
echo "🧹 Cleaning previous builds..."
./gradlew clean

echo "🏗️  Building debug APK..."
./gradlew assembleDebug

if [ $? -eq 0 ]; then
    echo "✅ Debug APK built successfully!"
    cd ..
    
    # Copy APK to root for easy download
    if [ -f "android/app/build/outputs/apk/debug/app-debug.apk" ]; then
        cp android/app/build/outputs/apk/debug/app-debug.apk ./CompatHub-debug.apk
        echo "📱 APK ready for download: CompatHub-debug.apk"
        echo "📊 APK Size: $(du -h CompatHub-debug.apk | cut -f1)"
        
        # Update download page
        echo "🌐 Updating download page..."
        APK_SIZE=$(du -h CompatHub-debug.apk | cut -f1)
        cat > download.html << EOF
<!DOCTYPE html>
<html>
<head>
    <title>Download CompatHub APK</title>
    <style>
        body { 
            font-family: Arial, sans-serif; 
            padding: 20px; 
            text-align: center; 
            background: linear-gradient(135deg, #1e3a8a, #3b82f6);
            color: white;
            min-height: 100vh;
            margin: 0;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
            background: rgba(255, 255, 255, 0.1);
            padding: 40px;
            border-radius: 20px;
            backdrop-filter: blur(10px);
        }
        .download-btn { 
            background: #10b981; 
            color: white; 
            padding: 15px 30px; 
            text-decoration: none; 
            border-radius: 10px; 
            display: inline-block; 
            margin: 20px;
            font-size: 18px;
            font-weight: bold;
            transition: background 0.3s;
        }
        .download-btn:hover {
            background: #059669;
        }
        .icon {
            font-size: 64px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="icon">📱</div>
        <h1>CompatHub Mobile App</h1>
        <p>Download the APK file and install on your Android device</p>
        <a href="./CompatHub-debug.apk" class="download-btn" download>📥 Download APK</a>
        <p><strong>Size:</strong> ${APK_SIZE}</p>
        <hr style="margin: 30px 0; border: 1px solid rgba(255,255,255,0.3);">
        <h3>📋 Installation Instructions:</h3>
        <div style="text-align: left; max-width: 400px; margin: 0 auto;">
            <p>1. 🔓 Enable "Unknown Sources" in Android Settings</p>
            <p>2. 📲 Download the APK file using the button above</p>
            <p>3. 📁 Open file manager and tap the APK to install</p>
            <p>4. ✅ Grant necessary permissions when prompted</p>
        </div>
    </div>
</body>
</html>
EOF
        
    else
        echo "❌ APK file not found after build"
        exit 1
    fi
else
    echo "❌ Debug APK build failed!"
    cd ..
    exit 1
fi

echo ""
echo "✅ Mobile APK build complete!"
echo "📁 APK Location: ./CompatHub-debug.apk"
echo "🌐 Download page: ./download.html"
echo ""
echo "🌍 Access your APK at: https://$(echo $REPL_SLUG)-$(echo $REPL_OWNER).replit.app/download.html"

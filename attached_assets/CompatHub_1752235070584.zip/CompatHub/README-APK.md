# CompatHub Mobile APK Build Guide

## Overview
CompatHub is now available as a native Android APK that can be installed on any Android device. The mobile app provides full compatibility testing functionality with offline capabilities.

## Features
- **Device Scanning**: Automatically detect hardware specifications
- **APK Analysis**: Upload and analyze APK files for compatibility
- **Popular Apps Database**: Pre-loaded with 10+ popular apps
- **Compatibility Testing**: AI-powered compatibility scoring
- **Emulation Options**: Virtual container support for incompatible apps
- **Offline Mode**: Core functionality works without internet
- **Database Sync**: Persistent storage with PostgreSQL backend

## Building the APK

### Prerequisites
- Node.js 18+ installed
- Android SDK installed (for advanced builds)
- Basic terminal/command line knowledge

### Quick Build (Automated)
```bash
# Run the automated build script
./build-mobile.sh
```

### Manual Build Steps
```bash
# 1. Build the web application
npm run build

# 2. Copy assets to native projects
npx cap copy

# 3. Sync native dependencies
npx cap sync

# 4. Build debug APK
cd android && ./gradlew assembleDebug && cd ..

# 5. Build release APK  
cd android && ./gradlew assembleRelease && cd ..
```

### Build Outputs
- **Debug APK**: `CompatHub-debug.apk` (for testing)
- **Release APK**: `CompatHub-release.apk` (for distribution)

## Installation Instructions

### Method 1: Direct Installation
1. Enable "Unknown Sources" in Android Settings:
   - Go to Settings > Security
   - Enable "Unknown Sources" or "Install Unknown Apps"
2. Transfer the APK file to your Android device
3. Open file manager and tap the APK file
4. Follow installation prompts
5. Grant required permissions when requested

### Method 2: ADB Installation (Advanced)
```bash
# Install via ADB (if connected to computer)
adb install CompatHub-debug.apk
```

## Permissions Required
The app requests the following permissions:
- **Storage**: For APK file uploads and caching
- **Internet**: For API communication and updates
- **Device Info**: For hardware specification detection

## App Architecture

### Frontend (React + Capacitor)
- Mobile-optimized React interface
- Capacitor for native device integration
- Offline-first design with local caching
- Responsive glassmorphism UI

### Backend Integration
- Express.js API server
- PostgreSQL database with Drizzle ORM
- Mobile-specific API endpoints
- Batch processing for efficiency

### Mobile-Specific Features
- Native file picker for APK uploads
- Hardware specification detection
- Background compatibility processing
- Offline data synchronization

## API Endpoints (Mobile)

### Core Endpoints
- `GET /api/mobile/config` - App configuration
- `GET /api/mobile/popular-apps` - Popular apps list
- `POST /api/mobile/sync-device` - Device specs sync
- `POST /api/mobile/batch-compatibility` - Batch compatibility check

### Data Sync
The mobile app automatically syncs with the backend:
- Device specifications on first launch
- Popular apps database weekly
- Compatibility results in real-time
- User preferences and history

## Troubleshooting

### Installation Issues
- **"App not installed"**: Enable Unknown Sources
- **"Parse error"**: Re-download APK file
- **"Insufficient storage"**: Free up 50MB+ space

### Performance Issues
- **Slow compatibility checks**: Ensure stable internet
- **App crashes**: Restart device and retry
- **Missing features**: Update to latest APK version

### Backend Connection
- **API errors**: Check internet connection
- **Sync failures**: Verify server status
- **Outdated data**: Manual refresh in settings

## Development Notes

### Technology Stack
- **Frontend**: React 18, TypeScript, Tailwind CSS
- **Mobile**: Capacitor 7, Android SDK 34
- **Backend**: Express.js, PostgreSQL, Drizzle ORM
- **Build**: Vite, ESBuild, Gradle

### File Structure
```
android/                 # Native Android project
├── app/src/main/       # Android manifest & resources
├── build.gradle        # Android build configuration
└── gradlew            # Gradle wrapper

capacitor.config.ts     # Capacitor configuration
build-mobile.sh        # Automated build script
scripts/seed-database.ts # Database seeding
server/mobile-api.ts   # Mobile API endpoints
```

### Build Configuration
- **App ID**: `com.compathub.app`
- **Target SDK**: Android 34 (Android 14)
- **Min SDK**: Android 21 (Android 5.0)
- **APK Size**: ~15-25MB (compressed)

## Distribution

### Internal Testing
1. Build debug APK for internal testing
2. Install on test devices
3. Verify all features work correctly
4. Test on various Android versions

### Public Release
1. Build signed release APK
2. Test thoroughly on multiple devices
3. Distribute via:
   - Direct download links
   - Internal app stores
   - Beta testing platforms

## Security Considerations
- APK is unsigned (for development)
- HTTPS communication with backend
- No sensitive data stored locally
- User permissions clearly defined
- Regular security updates recommended

## Support
For issues or questions:
1. Check the troubleshooting section
2. Verify device compatibility
3. Ensure latest APK version
4. Contact development team if needed